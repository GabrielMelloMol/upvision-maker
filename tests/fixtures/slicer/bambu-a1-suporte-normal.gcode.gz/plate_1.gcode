; HEADER_BLOCK_START
; BambuStudio 02.08.02.61
; model printing time: 17m 39s; total estimated time: 17m 58s
; total layer number: 176
; total filament length [mm] : 2322.74
; total filament volume [cm^3] : 5586.85
; total filament weight [g] : 7.04
; filament_density: 1.26
; filament_diameter: 1.75
; max_z_height: 24.00
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = auto_brim
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = M620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nG1 X70 F21000\nG1 Y245\nG1 Y265 F3000\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 X120 F15000\n\nG1 X20 Y50 F21000\nG1 Y-3\n{if toolchange_count == 2}\n; get travel path for change filament\nM620.1 X[travel_point_1_x] Y[travel_point_1_y] F21000 P0\nM620.1 X[travel_point_2_x] Y[travel_point_2_y] F21000 P1\nM620.1 X[travel_point_3_x] Y[travel_point_3_y] F21000 P2\n{endif}\nM620.1 E F[old_filament_e_feedrate] T{nozzle_temperature_range_high[previous_extruder]}\nT[next_extruder]\nM620.1 E F[new_filament_e_feedrate] T{nozzle_temperature_range_high[next_extruder]}\n\n{if next_extruder < 255}\nM400\n\nG92 E0\n{if flush_length_1 > 1}\n; FLUSH_START\n; always use highest temperature to flush\nM400\nM109 S[nozzle_temperature_range_high]\n{if flush_length_1 > 23.7}\nG1 E23.7 F{old_filament_e_feedrate} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{old_filament_e_feedrate}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{new_filament_e_feedrate}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{new_filament_e_feedrate}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{new_filament_e_feedrate}\n{else}\nG1 E{flush_length_1} F{old_filament_e_feedrate}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 1}\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 1}\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_4 > 1}\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{new_filament_e_feedrate}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n; FLUSH_START\nM400\nM109 S[new_filament_temp]\nG1 E2 F{new_filament_e_feedrate} ;Compensate for filament spillage during waiting temperature\n; FLUSH_END\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM106 P1 S255\nM400 S3\nG1 X80 F15000\nG1 X60 F15000\nG1 X80 F15000\nG1 X60 F15000; shake to put down garbage\n\nG1 X70 F5000\nG1 X90 F3000\nG1 Y255 F4000\nG1 X100 F5000\nG1 Y265 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X70 F10000\nG1 X100 F5000\nG1 X165 F15000; wipe and shake\nG1 Y256 ; move Y to aside, prevent collision\nM400\nG1 Z{max_layer_z + 3.0} F3000\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\nM621 S[next_extruder]A
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 6000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL A1"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL A1
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0.075
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 1
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 56.5
; extruder_clearance_height_to_lid = 256
; extruder_clearance_height_to_rod = 25
; extruder_clearance_max_radius = 73
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard"
; fan_cooling_layer_time = 80
; fan_direction = undefine
; fan_max_speed = 80
; fan_min_speed = 60
; farthest_point_timelapse = 0
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 5
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 19.99
; filament_density = 1.26
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFA00
; filament_is_mixed = 0
; filament_is_support = 0
; filament_long_retractions_when_cut = 1
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 21
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 0
; filament_prime_volume = 30
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_retraction_distances_when_cut = 18
; filament_scarf_gap = 0%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Bambu PLA Basic @BBL A1"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >55)||(bed_temperature_initial_layer[current_extruder] >55)}M106 P3 S200\n{elsif(bed_temperature[current_extruder] >50)||(bed_temperature_initial_layer[current_extruder] >50)}M106 P3 S150\n{elsif(bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S50\n{endif}\n\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = "Bambu Lab"
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 17.4
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 226x224,256x224,256x256,226x256
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 65
; hot_plate_temp_initial_layer = 65
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 13.8
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20230428 =====================\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG1 E-0.8 F1800 ; retract\nG1 Z{max_layer_z + 0.5} F900 ; lower z a little\nG1 X65 Y245 F12000 ; move to safe pos \nG1 Y265 F3000\n\nG1 X65 Y245 F12000\nG1 Y265 F3000\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\nG1 X100 F12000 ; wipe\n; pull back filament to AMS\nM620 S255\nG1 X20 Y50 F12000\nG1 Y-3\nT255\nG1 X65 F12000\nG1 Y265\nG1 X100 F12000 ; wipe\nM621 S255\nM104 S0 ; turn off hotend\n\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n    M400 ; wait all motion done\n    M991 S0 P-1 ;end smooth timelapse at safe pos\n    M400 S3 ;wait for last picture to be taken\nM623; end of \"timelapse_record_flag\"\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 250}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z250 F600\n    G1 Z248\n{endif}\nM400 P100\nM17 R ; restore z current\n\nG90\nG1 X128 Y250 F3600\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n\nM17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 25
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 12000,12000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 6000,6000
; machine_max_acceleration_x = 6000,6000
; machine_max_acceleration_y = 6000,6000
; machine_max_acceleration_z = 1500,1500
; machine_max_force_Y = 0
; machine_max_jerk_e = 3,3
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 3,3
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,200
; machine_max_speed_y = 500,200
; machine_max_speed_z = 30,30
; machine_min_extruding_rate = 0,0
; machine_min_travel_rate = 0,0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = G0 Z20 F9000\nG92 E0; G1 E-10 F1200\nG28\nM970 Q1 A10 B10 C130 K0\nM970 Q1 A10 B131 C250 K1\nM974 Q1 S1 P0\nM970 Q0 A10 B10 C130 H20 K0\nM970 Q0 A10 B131 C250 K1\nM974 Q0 S1 P0\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nG29 ;Home\nG90;\nG92 E0 ;Reset Extruder \nG1 Z2.0 F3000 ;Move Z Axis up \nG1 X10.1 Y20 Z0.28 F5000.0 ;Move to start position\nM109 S205;\nG1 X10.1 Y200.0 Z0.28 F1500.0 E15 ;Draw the first line\nG1 X10.4 Y200.0 Z0.28 F5000.0 ;Move to side a little\nG1 X10.4 Y20 Z0.28 F1500.0 E30 ;Draw the second line\nG92 E0 ;Reset Extruder \nG1 X110 Y110 Z2.0 F3000 ;Move Z Axis up
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 29
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.76
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = stainless_steel
; nozzle_volume = 92
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 2
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab A1 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL A1
; printable_area = 0x0,256x0,256x256,0x256
; printable_height = 256
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab A1
; printer_notes = 
; printer_settings_id = Bambu Lab A1 0.4 nozzle
; printer_structure = i3
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 255
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 6
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 80
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 15%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = normal(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 65
; textured_plate_temp_initial_layer = 65
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;========Date 20250206========\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\n{if timelapse_type == 0} ; timelapse without wipe tower\nM971 S11 C10 O0\n{elsif timelapse_type == 1} ; timelapse with wipe tower\nG92 E0\nG1 X65 Y245 F20000 ; move to safe pos\nG17\nG2 Z{layer_z} I0.86 J0.86 P1 F20000\nG1 Y265 F3000\nM400 P300\nM971 S11 C10 O0\nG92 E0\nG1 X100 F5000\nG1 Y255 F20000\n{endif}\nM623\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 700
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R17
M201 X6000 Y6000 Z1500 E5000
M203 X500 Y500 Z30 E30
M204 P12000 R5000 T12000
M205 X9.00 Y9.00 Z3.00 E3.00
M106 S0
M190 S35 ; set bed temperature and wait for it to be reached
; FEATURE: Custom
G0 Z20 F9000
G92 E0; G1 E-10 F1200
G28
M970 Q1 A10 B10 C130 K0
M970 Q1 A10 B131 C250 K1
M974 Q1 S1 P0
M970 Q0 A10 B10 C130 H20 K0
M970 Q0 A10 B131 C250 K1
M974 Q0 S1 P0
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
G29 ;Home
G90;
G92 E0 ;Reset Extruder 
G1 Z2.0 F3000 ;Move Z Axis up 
G1 X10.1 Y20 Z0.28 F5000.0 ;Move to start position
M109 S205;
G1 X10.1 Y200.0 Z0.28 F1500.0 E15 ;Draw the first line
G1 X10.4 Y200.0 Z0.28 F5000.0 ;Move to side a little
G1 X10.4 Y20 Z0.28 F1500.0 E30 ;Draw the second line
G92 E0 ;Reset Extruder 
G1 X110 Y110 Z2.0 F3000 ;Move Z Axis up
; MACHINE_START_GCODE_END
; filament start gcode


;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/176
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
; OBJECT_ID: 15
M73 P1 R17
G1 X150.078 Y141.447 F42000
M204 S6000
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X105.922 Y141.447 E1.64465
G1 X105.922 Y114.553 E1.00168
G1 X150.078 Y114.553 E1.64465
G1 X150.078 Y141.378 E.99913
; WIPE_START
G1 X150.078 Y139.378 E-.76
; WIPE_END
M73 P2 R17
G1 E-.04 F1800
M204 S6000
G1 X143.311 Y135.849 Z.6 F42000
G1 X117.814 Y122.55 Z.6
G1 Z.2
G1 E.8 F1800
G1 F3000
M204 S500
G1 X128.186 Y122.55 E.38635
G1 X128.45 Y122.814 E.01389
G1 X128.45 Y133.186 E.38635
G1 X128.186 Y133.45 E.01389
G1 X117.814 Y133.45 E.38635
G1 X117.55 Y133.186 E.01389
G1 X117.55 Y122.814 E.38635
G1 X117.765 Y122.598 E.01133
; WIPE_START
G1 X117.55 Y122.814 E-.11561
G1 X117.55 Y124.509 E-.64439
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X124.304 Y128.065 Z.6 F42000
G1 X149.33 Y141.241 Z.6
G1 Z.2
G1 E.8 F1800
G1 F3000
M204 S500
G1 X149.33 Y114.965 E.9787
G1 X148.822 Y114.965 E.01892
G1 X148.822 Y141.035 E.97104
G1 X148.314 Y141.035 E.01892
G1 X148.314 Y114.965 E.97104
G1 X147.807 Y114.965 E.01892
G1 X147.807 Y141.035 E.97104
G1 X147.299 Y141.035 E.01892
G1 X147.299 Y114.965 E.97104
G1 X146.791 Y114.965 E.01892
G1 X146.791 Y141.035 E.97104
G1 X146.283 Y141.035 E.01892
G1 X146.283 Y114.965 E.97104
G1 X145.775 Y114.965 E.01892
G1 X145.775 Y141.035 E.97104
G1 X145.267 Y141.035 E.01892
G1 X145.267 Y114.965 E.97104
G1 X144.759 Y114.965 E.01892
G1 X144.759 Y141.035 E.97104
G1 X144.252 Y141.035 E.01892
G1 X144.252 Y114.965 E.97104
G1 X143.744 Y114.965 E.01892
G1 X143.744 Y141.035 E.97104
G1 X143.236 Y141.035 E.01892
G1 X143.236 Y114.965 E.97104
G1 X142.728 Y114.965 E.01892
G1 X142.728 Y141.035 E.97104
G1 X142.22 Y141.035 E.01892
G1 X142.22 Y114.965 E.97104
M73 P3 R17
G1 X141.712 Y114.965 E.01892
G1 X141.712 Y141.035 E.97104
G1 X141.204 Y141.035 E.01892
G1 X141.204 Y114.965 E.97104
G1 X140.696 Y114.965 E.01892
G1 X140.696 Y141.035 E.97104
G1 X140.189 Y141.035 E.01892
G1 X140.189 Y114.965 E.97104
G1 X139.681 Y114.965 E.01892
G1 X139.681 Y141.035 E.97104
G1 X139.173 Y141.035 E.01892
G1 X139.173 Y114.965 E.97104
G1 X138.665 Y114.965 E.01892
G1 X138.665 Y141.035 E.97104
G1 X138.157 Y141.035 E.01892
G1 X138.157 Y114.965 E.97104
G1 X137.649 Y114.965 E.01892
G1 X137.649 Y141.035 E.97104
G1 X137.141 Y141.035 E.01892
G1 X137.141 Y114.965 E.97104
G1 X136.634 Y114.965 E.01892
G1 X136.634 Y141.035 E.97104
G1 X136.126 Y141.035 E.01892
G1 X136.126 Y114.965 E.97104
G1 X135.618 Y114.965 E.01892
G1 X135.618 Y141.035 E.97104
G1 X135.11 Y141.035 E.01892
G1 X135.11 Y114.965 E.97104
G1 X134.602 Y114.965 E.01892
G1 X134.602 Y141.035 E.97104
G1 X134.094 Y141.035 E.01892
G1 X134.094 Y114.965 E.97104
G1 X133.586 Y114.965 E.01892
G1 X133.586 Y141.035 E.97104
M73 P4 R17
G1 X133.079 Y141.035 E.01892
G1 X133.079 Y114.965 E.97104
G1 X132.571 Y114.965 E.01892
G1 X132.571 Y141.035 E.97104
G1 X132.063 Y141.035 E.01892
G1 X132.063 Y114.965 E.97104
G1 X131.555 Y114.965 E.01892
G1 X131.555 Y141.035 E.97104
G1 X131.047 Y141.035 E.01892
G1 X131.047 Y114.965 E.97104
G1 X130.539 Y114.965 E.01892
G1 X130.539 Y141.035 E.97104
G1 X130.031 Y141.035 E.01892
G1 X130.031 Y114.965 E.97104
G1 X129.524 Y114.965 E.01892
G1 X129.524 Y141.035 E.97104
G1 X129.016 Y141.035 E.01892
G1 X129.016 Y114.965 E.97104
G1 X128.508 Y114.965 E.01892
G1 X128.508 Y122.29 E.27283
G1 X128.357 Y122.139 E.00796
G1 X128 Y122.139 E.01329
G1 X128 Y114.965 E.26721
G1 X127.492 Y114.965 E.01892
G1 X127.492 Y122.139 E.26721
G1 X126.984 Y122.139 E.01892
G1 X126.984 Y114.965 E.26721
G1 X126.476 Y114.965 E.01892
G1 X126.476 Y122.139 E.26721
G1 X125.969 Y122.139 E.01892
G1 X125.969 Y114.965 E.26721
G1 X125.461 Y114.965 E.01892
G1 X125.461 Y122.139 E.26721
G1 X124.953 Y122.139 E.01892
G1 X124.953 Y114.965 E.26721
G1 X124.445 Y114.965 E.01892
G1 X124.445 Y122.139 E.26721
G1 X123.937 Y122.139 E.01892
G1 X123.937 Y114.965 E.26721
G1 X123.429 Y114.965 E.01892
G1 X123.429 Y122.139 E.26721
G1 X122.921 Y122.139 E.01892
G1 X122.921 Y114.965 E.26721
G1 X122.414 Y114.965 E.01892
G1 X122.414 Y122.139 E.26721
G1 X121.906 Y122.139 E.01892
G1 X121.906 Y114.965 E.26721
G1 X121.398 Y114.965 E.01892
G1 X121.398 Y122.139 E.26721
G1 X120.89 Y122.139 E.01892
G1 X120.89 Y114.965 E.26721
G1 X120.382 Y114.965 E.01892
G1 X120.382 Y122.139 E.26721
G1 X119.874 Y122.139 E.01892
G1 X119.874 Y114.965 E.26721
M73 P5 R17
G1 X119.366 Y114.965 E.01892
G1 X119.366 Y122.139 E.26721
G1 X118.859 Y122.139 E.01892
G1 X118.859 Y114.965 E.26721
G1 X118.351 Y114.965 E.01892
G1 X118.351 Y122.139 E.26721
G1 X117.843 Y122.139 E.01892
G1 X117.843 Y114.965 E.26721
G1 X117.335 Y114.965 E.01892
G1 X117.335 Y141.035 E.97104
G1 X117.843 Y141.035 E.01892
G1 X117.843 Y133.861 E.26721
G1 X118.351 Y133.861 E.01892
G1 X118.351 Y141.035 E.26721
G1 X118.859 Y141.035 E.01892
G1 X118.859 Y133.861 E.26721
G1 X119.366 Y133.861 E.01892
G1 X119.366 Y141.035 E.26721
G1 X119.874 Y141.035 E.01892
G1 X119.874 Y133.861 E.26721
G1 X120.382 Y133.861 E.01892
G1 X120.382 Y141.035 E.26721
G1 X120.89 Y141.035 E.01892
G1 X120.89 Y133.861 E.26721
G1 X121.398 Y133.861 E.01892
G1 X121.398 Y141.035 E.26721
G1 X121.906 Y141.035 E.01892
G1 X121.906 Y133.861 E.26721
G1 X122.414 Y133.861 E.01892
G1 X122.414 Y141.035 E.26721
G1 X122.921 Y141.035 E.01892
G1 X122.921 Y133.861 E.26721
G1 X123.429 Y133.861 E.01892
G1 X123.429 Y141.035 E.26721
G1 X123.937 Y141.035 E.01892
G1 X123.937 Y133.861 E.26721
G1 X124.445 Y133.861 E.01892
G1 X124.445 Y141.035 E.26721
G1 X124.953 Y141.035 E.01892
G1 X124.953 Y133.861 E.26721
M73 P5 R16
G1 X125.461 Y133.861 E.01892
G1 X125.461 Y141.035 E.26721
G1 X125.969 Y141.035 E.01892
G1 X125.969 Y133.861 E.26721
G1 X126.476 Y133.861 E.01892
G1 X126.476 Y141.035 E.26721
G1 X126.984 Y141.035 E.01892
G1 X126.984 Y133.861 E.26721
G1 X127.492 Y133.861 E.01892
G1 X127.492 Y141.035 E.26721
G1 X128 Y141.035 E.01892
G1 X128 Y133.861 E.26721
G1 X128.357 Y133.861 E.01329
G1 X128.508 Y133.71 E.00796
G1 X128.508 Y141.241 E.2805
M204 S6000
G1 X116.827 Y141.241 F42000
G1 F3000
M204 S500
G1 X116.827 Y114.965 E.9787
G1 X116.319 Y114.965 E.01892
G1 X116.319 Y141.035 E.97104
G1 X115.811 Y141.035 E.01892
G1 X115.811 Y114.965 E.97104
G1 X115.303 Y114.965 E.01892
G1 X115.303 Y141.035 E.97104
G1 X114.796 Y141.035 E.01892
G1 X114.796 Y114.965 E.97104
G1 X114.288 Y114.965 E.01892
G1 X114.288 Y141.035 E.97104
G1 X113.78 Y141.035 E.01892
G1 X113.78 Y114.965 E.97104
M73 P6 R16
G1 X113.272 Y114.965 E.01892
G1 X113.272 Y141.035 E.97104
G1 X112.764 Y141.035 E.01892
G1 X112.764 Y114.965 E.97104
G1 X112.256 Y114.965 E.01892
G1 X112.256 Y141.035 E.97104
G1 X111.748 Y141.035 E.01892
G1 X111.748 Y114.965 E.97104
G1 X111.241 Y114.965 E.01892
G1 X111.241 Y141.035 E.97104
G1 X110.733 Y141.035 E.01892
G1 X110.733 Y114.965 E.97104
G1 X110.225 Y114.965 E.01892
G1 X110.225 Y141.035 E.97104
G1 X109.717 Y141.035 E.01892
G1 X109.717 Y114.965 E.97104
G1 X109.209 Y114.965 E.01892
G1 X109.209 Y141.035 E.97104
G1 X108.701 Y141.035 E.01892
G1 X108.701 Y114.965 E.97104
G1 X108.193 Y114.965 E.01892
G1 X108.193 Y141.035 E.97104
G1 X107.686 Y141.035 E.01892
G1 X107.686 Y114.965 E.97104
G1 X107.178 Y114.965 E.01892
G1 X107.178 Y141.035 E.97104
G1 X106.67 Y141.035 E.01892
G1 X106.67 Y114.759 E.9787
; WIPE_START
G1 X106.67 Y116.759 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X111.377 Y122.767 Z.6 F42000
G1 X118.782 Y132.218 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F3000
M204 S500
G1 X118.782 Y123.782 E.3142
G1 X127.218 Y123.782 E.3142
G1 X127.218 Y132.218 E.3142
G1 X118.842 Y132.218 E.31197
M204 S6000
G1 X118.325 Y132.675 F42000
; FEATURE: Outer wall
M73 P7 R16
G1 F3000
M204 S500
G1 X118.325 Y123.325 E.34825
G1 X127.675 Y123.325 E.34825
G1 X127.675 Y132.675 E.34825
G1 X118.385 Y132.675 E.34602
; WIPE_START
G1 X118.372 Y130.675 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G17
G3 Z.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X126.107 Y123.965
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.50202
G1 F6300
M204 S500
G1 X126.829 Y124.687 E.03823
G1 X126.829 Y125.337 E.02429
G1 X125.663 Y124.171 E.0617
G1 X125.014 Y124.171 E.02429
G1 X126.829 Y125.986 E.09605
G1 X126.829 Y126.635 E.02429
G1 X124.365 Y124.171 E.1304
G1 X123.715 Y124.171 E.02429
G1 X126.829 Y127.285 E.16475
G1 X126.829 Y127.934 E.02429
G1 X123.066 Y124.171 E.1991
G1 X122.417 Y124.171 E.02429
G1 X126.829 Y128.583 E.23345
G1 X126.829 Y129.232 E.02429
G1 X121.768 Y124.171 E.2678
G1 X121.118 Y124.171 E.02429
G1 X126.829 Y129.882 E.30215
G1 X126.829 Y130.531 E.02429
G1 X120.469 Y124.171 E.3365
G1 X119.82 Y124.171 E.02429
G1 X126.829 Y131.18 E.37085
G1 X126.829 Y131.829 E.02429
G1 X119.171 Y124.171 E.4052
G1 X119.171 Y124.82 E.02429
G1 X126.18 Y131.829 E.37086
G1 X125.531 Y131.829 E.02429
G1 X119.171 Y125.469 E.33651
G1 X119.171 Y126.118 E.02429
G1 X124.882 Y131.829 E.30216
G1 X124.232 Y131.829 E.02429
G1 X119.171 Y126.768 E.2678
G1 X119.171 Y127.417 E.02429
G1 X123.583 Y131.829 E.23345
G1 X122.934 Y131.829 E.02429
G1 X119.171 Y128.066 E.1991
G1 X119.171 Y128.715 E.02429
G1 X122.285 Y131.829 E.16475
G1 X121.635 Y131.829 E.02429
G1 X119.171 Y129.365 E.1304
G1 X119.171 Y130.014 E.02429
G1 X120.986 Y131.829 E.09605
G1 X120.337 Y131.829 E.02429
G1 X119.171 Y130.663 E.0617
G1 X119.171 Y131.312 E.02429
G1 X119.893 Y132.035 E.03823
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X119.171 Y131.312 E-.38835
G1 X119.171 Y130.663 E-.24672
G1 X119.403 Y130.896 E-.12493
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/176
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S201.45
; open powerlost recovery
M1003 S1
; OBJECT_ID: 15
M204 S10000
G17
G3 Z.6 I-1.074 J-.573 P1  F42000
G1 X118.602 Y132.398 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F2668
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F2668
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X119.551 Y123.766
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43098
G1 F2668
M204 S6000
G1 X118.935 Y124.381 E.02754
G1 X118.935 Y124.93 E.01735
G1 X119.93 Y123.935 E.04449
G1 X120.479 Y123.935 E.01735
G1 X118.935 Y125.479 E.06904
G1 X118.935 Y126.028 E.01735
G1 X121.028 Y123.935 E.09358
G1 X121.577 Y123.935 E.01735
G1 X118.935 Y126.577 E.11812
G1 X118.935 Y127.125 E.01735
G1 X122.125 Y123.935 E.14266
G1 X122.674 Y123.935 E.01735
G1 X118.935 Y127.674 E.16721
G1 X118.935 Y128.223 E.01735
G1 X123.223 Y123.935 E.19175
G1 X123.772 Y123.935 E.01735
G1 X118.935 Y128.772 E.21629
G1 X118.935 Y129.321 E.01735
G1 X124.321 Y123.935 E.24083
G1 X124.869 Y123.935 E.01735
G1 X118.935 Y129.869 E.26537
G1 X118.935 Y130.418 E.01735
G1 X125.418 Y123.935 E.28992
G1 X125.967 Y123.935 E.01735
G1 X118.935 Y130.967 E.31446
G1 X118.935 Y131.516 E.01735
G1 X126.516 Y123.935 E.339
G1 X127.065 Y123.935 E.01735
G1 X118.935 Y132.065 E.36354
M73 P8 R16
G1 X119.484 Y132.065 E.01735
G1 X127.065 Y124.484 E.33901
G1 X127.065 Y125.033 E.01735
G1 X120.033 Y132.065 E.31446
G1 X120.582 Y132.065 E.01735
G1 X127.065 Y125.582 E.28992
G1 X127.065 Y126.13 E.01735
G1 X121.13 Y132.065 E.26538
G1 X121.679 Y132.065 E.01735
G1 X127.065 Y126.679 E.24084
G1 X127.065 Y127.228 E.01735
G1 X122.228 Y132.065 E.21629
G1 X122.777 Y132.065 E.01735
G1 X127.065 Y127.777 E.19175
G1 X127.065 Y128.326 E.01735
G1 X123.326 Y132.065 E.16721
G1 X123.874 Y132.065 E.01735
G1 X127.065 Y128.874 E.14267
G1 X127.065 Y129.423 E.01735
G1 X124.423 Y132.065 E.11812
G1 X124.972 Y132.065 E.01735
G1 X127.065 Y129.972 E.09358
G1 X127.065 Y130.521 E.01735
G1 X125.521 Y132.065 E.06904
G1 X126.07 Y132.065 E.01735
G1 X127.065 Y131.07 E.0445
G1 X127.065 Y131.618 E.01735
G1 X126.449 Y132.234 E.02754
; CHANGE_LAYER
; Z_HEIGHT: 0.48
; LAYER_HEIGHT: 0.08
; WIPE_START
G1 F15000
G1 X127.065 Y131.618 E-.33098
G1 X127.065 Y131.07 E-.20854
G1 X126.654 Y131.48 E-.22047
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/176
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z.8 I-.932 J.782 P1  F42000
G1 X128.309 Y133.452 Z.8
G1 Z.48
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F6545
M204 S6000
G1 X128.539 Y133.223 E.01332
G1 X128.539 Y130.877 E.09633
G1 X148.14 Y130.877 E.80481
G1 X148.14 Y128 E.11813
G1 X128.539 Y128 E.80481
G1 X128.539 Y125.123 E.11813
G1 X148.14 Y125.123 E.80481
G1 X148.14 Y122.246 E.11813
G1 X107.86 Y122.246 E1.65384
G1 X107.86 Y119.369 E.11813
G1 X148.14 Y119.369 E1.65384
G1 X148.14 Y116.492 E.11813
G1 X107.86 Y116.492 E1.65384
M204 S10000
G1 X107.86 Y122.434 F42000
G1 F6545
M204 S6000
G1 X107.86 Y125.123 E.11039
G1 X117.461 Y125.123 E.39421
G1 X117.461 Y128 E.11813
G1 X107.86 Y128 E.39421
G1 X107.86 Y130.877 E.11813
G1 X117.461 Y130.877 E.39421
G1 X117.461 Y133.223 E.09633
G1 X117.691 Y133.452 E.01332
M204 S10000
G1 X107.86 Y131.066 F42000
G1 F6545
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z.88 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 4/176
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F6545
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6545
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.766 Y131.449
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.43098
G1 F6545
M204 S6000
G1 X119.381 Y132.065 E.02754
G1 X119.93 Y132.065 E.01735
G1 X118.935 Y131.07 E.04449
G1 X118.935 Y130.521 E.01735
G1 X120.479 Y132.065 E.06904
G1 X121.028 Y132.065 E.01735
G1 X118.935 Y129.972 E.09358
G1 X118.935 Y129.423 E.01735
G1 X121.577 Y132.065 E.11812
G1 X122.125 Y132.065 E.01735
G1 X118.935 Y128.875 E.14266
G1 X118.935 Y128.326 E.01735
G1 X122.674 Y132.065 E.1672
G1 X123.223 Y132.065 E.01735
G1 X118.935 Y127.777 E.19175
G1 X118.935 Y127.228 E.01735
G1 X123.772 Y132.065 E.21629
G1 X124.321 Y132.065 E.01735
G1 X118.935 Y126.679 E.24083
G1 X118.935 Y126.131 E.01735
G1 X124.869 Y132.065 E.26537
G1 X125.418 Y132.065 E.01735
G1 X118.935 Y125.582 E.28992
G1 X118.935 Y125.033 E.01735
G1 X125.967 Y132.065 E.31446
G1 X126.516 Y132.065 E.01735
G1 X118.935 Y124.484 E.339
G1 X118.935 Y123.935 E.01735
G1 X127.065 Y132.065 E.36354
G1 X127.065 Y131.516 E.01735
G1 X119.484 Y123.935 E.33901
G1 X120.033 Y123.935 E.01735
G1 X127.065 Y130.967 E.31446
G1 X127.065 Y130.418 E.01735
G1 X120.582 Y123.935 E.28992
G1 X121.13 Y123.935 E.01735
G1 X127.065 Y129.87 E.26538
G1 X127.065 Y129.321 E.01735
G1 X121.679 Y123.935 E.24084
G1 X122.228 Y123.935 E.01735
G1 X127.065 Y128.772 E.21629
G1 X127.065 Y128.223 E.01735
G1 X122.777 Y123.935 E.19175
G1 X123.326 Y123.935 E.01735
G1 X127.065 Y127.674 E.16721
G1 X127.065 Y127.126 E.01735
G1 X123.874 Y123.935 E.14267
G1 X124.423 Y123.935 E.01735
G1 X127.065 Y126.577 E.11812
G1 X127.065 Y126.028 E.01735
G1 X124.972 Y123.935 E.09358
G1 X125.521 Y123.935 E.01735
G1 X127.065 Y125.479 E.06904
G1 X127.065 Y124.93 E.01735
G1 X126.07 Y123.935 E.0445
G1 X126.618 Y123.935 E.01735
G1 X127.234 Y124.551 E.02754
; CHANGE_LAYER
; Z_HEIGHT: 0.76
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15000
G1 X126.618 Y123.935 E-.33098
G1 X126.07 Y123.935 E-.20854
G1 X126.48 Y124.346 E-.22048
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/176
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1 I-1.193 J.24 P1  F42000
G1 X128.309 Y133.452 Z1
G1 Z.76
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4937
M204 S6000
G1 X128.539 Y133.223 E.01332
G1 X128.539 Y130.877 E.09633
G1 X148.14 Y130.877 E.80481
G1 X148.14 Y128 E.11813
G1 X128.539 Y128 E.80481
M73 P9 R16
G1 X128.539 Y125.123 E.11813
G1 X148.14 Y125.123 E.80481
G1 X148.14 Y122.246 E.11813
G1 X107.86 Y122.246 E1.65384
G1 X107.86 Y119.369 E.11813
G1 X148.14 Y119.369 E1.65384
G1 X148.14 Y116.492 E.11813
G1 X107.86 Y116.492 E1.65384
M204 S10000
G1 X107.86 Y122.434 F42000
G1 F4937
M204 S6000
G1 X107.86 Y125.123 E.11039
G1 X117.461 Y125.123 E.39421
G1 X117.461 Y128 E.11813
G1 X107.86 Y128 E.39421
G1 X107.86 Y130.877 E.11813
G1 X117.461 Y130.877 E.39421
G1 X117.461 Y133.223 E.09633
G1 X117.691 Y133.452 E.01332
M204 S10000
G1 X107.86 Y131.066 F42000
G1 F4937
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.16 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 6/176
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4937
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4937
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4937
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/176
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.2 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
M73 P10 R16
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.04
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/176
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z1.4
G1 Z1.04
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.44 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z1.44
G1 Z1.04
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.44 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 9/176
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.32
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/176
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z1.6
G1 Z1.32
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
M73 P11 R16
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
M73 P11 R15
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.72 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z1.72
G1 Z1.32
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.72 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 11/176
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/176
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z2
G1 Z1.6
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
M73 P12 R15
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/176
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.88
; LAYER_HEIGHT: 0.08
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/176
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z2.2
G1 Z1.88
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.28 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z2.28
G1 Z1.88
G1 E.8 F1800
M73 P13 R15
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.28 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 15/176
; update layer progress
M73 L15
M991 S0 P14 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.16
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 16/176
; update layer progress
M73 L16
M991 S0 P15 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z2.4
G1 Z2.16
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.56 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z2.56
G1 Z2.16
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.56 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 17/176
; update layer progress
M73 L17
M991 S0 P16 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
M73 P14 R15
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 18/176
; update layer progress
M73 L18
M991 S0 P17 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.6 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.44
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 19/176
; update layer progress
M73 L19
M991 S0 P18 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z2.8
G1 Z2.44
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.84 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z2.84
G1 Z2.44
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
M73 P15 R15
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.84 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 20/176
; update layer progress
M73 L20
M991 S0 P19 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 2.72
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 21/176
; update layer progress
M73 L21
M991 S0 P20 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z3
G1 Z2.72
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.12 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z3.12
G1 Z2.72
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.12 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 22/176
; update layer progress
M73 L22
M991 S0 P21 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 23/176
; update layer progress
M73 L23
M991 S0 P22 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
M73 P16 R15
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.4 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z3.4
G1 Z3
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.4 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 24/176
; update layer progress
M73 L24
M991 S0 P23 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3.4 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
M73 P16 R14
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
M73 P17 R14
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.28
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 25/176
; update layer progress
M73 L25
M991 S0 P24 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z3.6
G1 Z3.28
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.68 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z3.68
G1 Z3.28
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.68 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 26/176
; update layer progress
M73 L26
M991 S0 P25 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.56
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 27/176
; update layer progress
M73 L27
M991 S0 P26 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z3.8
G1 Z3.56
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
M73 P18 R14
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.96 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z3.96
G1 Z3.56
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.96 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 28/176
; update layer progress
M73 L28
M991 S0 P27 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 29/176
; update layer progress
M73 L29
M991 S0 P28 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z4 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 3.84
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 30/176
; update layer progress
M73 L30
M991 S0 P29 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z4.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z4.2
G1 Z3.84
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
M73 P19 R14
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.24 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z4.24
G1 Z3.84
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.24 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 31/176
; update layer progress
M73 L31
M991 S0 P30 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.12
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 32/176
; update layer progress
M73 L32
M991 S0 P31 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z4.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z4.4
G1 Z4.12
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.52 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z4.52
G1 Z4.12
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
M73 P20 R14
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.52 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 33/176
; update layer progress
M73 L33
M991 S0 P32 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 34/176
; update layer progress
M73 L34
M991 S0 P33 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z4.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.8 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z4.8
G1 Z4.4
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.8 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z4.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 35/176
; update layer progress
M73 L35
M991 S0 P34 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z4.8 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
M73 P21 R14
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.68
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 36/176
; update layer progress
M73 L36
M991 S0 P35 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z5 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z5
G1 Z4.68
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.08 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z5.08
G1 Z4.68
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.08 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 37/176
; update layer progress
M73 L37
M991 S0 P36 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
M73 P22 R14
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 4.96
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 38/176
; update layer progress
M73 L38
M991 S0 P37 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z5.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z5.2
G1 Z4.96
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
M73 P22 R13
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.36 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z5.36
G1 Z4.96
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.36 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 39/176
; update layer progress
M73 L39
M991 S0 P38 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 40/176
; update layer progress
M73 L40
M991 S0 P39 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z5.4 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
M73 P23 R13
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 5.24
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 41/176
; update layer progress
M73 L41
M991 S0 P40 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z5.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z5.6
G1 Z5.24
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.64 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z5.64
G1 Z5.24
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.64 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 42/176
; update layer progress
M73 L42
M991 S0 P41 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z5.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 5.52
; LAYER_HEIGHT: 0.12
; WIPE_START
M73 P24 R13
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 43/176
; update layer progress
M73 L43
M991 S0 P42 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z5.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z5.8
G1 Z5.52
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.92 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z5.92
G1 Z5.52
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z5.92 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 44/176
; update layer progress
M73 L44
M991 S0 P43 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z5.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 45/176
; update layer progress
M73 L45
M991 S0 P44 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z6
G1 Z5.8
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.2 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z6.2
G1 Z5.8
M73 P25 R13
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.2 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z5.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 46/176
; update layer progress
M73 L46
M991 S0 P45 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z6.2 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z6.2
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6.08
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 47/176
; update layer progress
M73 L47
M991 S0 P46 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z6.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z6.4
G1 Z6.08
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
M73 P26 R13
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.48 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z6.48
G1 Z6.08
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.48 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 48/176
; update layer progress
M73 L48
M991 S0 P47 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z6.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6.36
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 49/176
; update layer progress
M73 L49
M991 S0 P48 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z6.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z6.6
G1 Z6.36
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.76 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z6.76
G1 Z6.36
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
M73 P27 R13
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.76 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 50/176
; update layer progress
M73 L50
M991 S0 P49 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z6.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z6.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 51/176
; update layer progress
M73 L51
M991 S0 P50 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z6.8 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z6.8
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6.64
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
M73 P27 R12
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 52/176
; update layer progress
M73 L52
M991 S0 P51 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z7 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z7
G1 Z6.64
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
M73 P28 R12
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.04 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z7.04
G1 Z6.64
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.04 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 6.8
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 53/176
; update layer progress
M73 L53
M991 S0 P52 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z6.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 6.92
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 54/176
; update layer progress
M73 L54
M991 S0 P53 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z7.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z7.2
G1 Z6.92
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.32 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z7.32
G1 Z6.92
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.32 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 7
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 55/176
; update layer progress
M73 L55
M991 S0 P54 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
M73 P29 R12
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z7
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 7.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 56/176
; update layer progress
M73 L56
M991 S0 P55 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z7.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z7.4
G1 Z7.2
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.6 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z7.6
G1 Z7.2
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.6 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z7.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 7.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 57/176
; update layer progress
M73 L57
M991 S0 P56 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z7.6 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z7.6
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
M73 P30 R12
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z7.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 7.48
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 58/176
; update layer progress
M73 L58
M991 S0 P57 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z7.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z7.8
G1 Z7.48
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.88 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z7.88
G1 Z7.48
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z7.88 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 7.6
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 59/176
; update layer progress
M73 L59
M991 S0 P58 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z7.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 7.76
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 60/176
; update layer progress
M73 L60
M991 S0 P59 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z8
G1 Z7.76
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
M73 P31 R12
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.16 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z8.16
G1 Z7.76
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.16 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 7.8
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 61/176
; update layer progress
M73 L61
M991 S0 P60 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z7.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 62/176
; update layer progress
M73 L62
M991 S0 P61 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z8.2 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z8.2
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
M73 P32 R12
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8.04
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 63/176
; update layer progress
M73 L63
M991 S0 P62 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z8.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z8.4
G1 Z8.04
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.44 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z8.44
G1 Z8.04
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.44 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 8.2
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 64/176
; update layer progress
M73 L64
M991 S0 P63 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z8.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8.32
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 65/176
; update layer progress
M73 L65
M991 S0 P64 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z8.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z8.6
G1 Z8.32
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
M73 P33 R12
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.72 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z8.72
G1 Z8.32
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.72 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 8.4
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 66/176
; update layer progress
M73 L66
M991 S0 P65 ;notify layer change
; OBJECT_ID: 15
M73 P33 R11
G1 X118.602 Y132.398
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z8.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z8.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 67/176
; update layer progress
M73 L67
M991 S0 P66 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z8.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z8.8
G1 Z8.6
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z9
G1 Z8.6
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
M73 P34 R11
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z8.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 68/176
; update layer progress
M73 L68
M991 S0 P67 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z9 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z9
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z8.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 8.88
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 69/176
; update layer progress
M73 L69
M991 S0 P68 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z9.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z9.2
G1 Z8.88
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.28 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z9.28
G1 Z8.88
G1 E.8 F1800
M73 P35 R11
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.28 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 9
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 70/176
; update layer progress
M73 L70
M991 S0 P69 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z9
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 9.16
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 71/176
; update layer progress
M73 L71
M991 S0 P70 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z9.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z9.4
G1 Z9.16
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.56 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z9.56
G1 Z9.16
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.56 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 9.2
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 72/176
; update layer progress
M73 L72
M991 S0 P71 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z9.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z9.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
M73 P36 R11
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 9.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 73/176
; update layer progress
M73 L73
M991 S0 P72 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z9.6 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z9.6
G1 Z9.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z9.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 9.44
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 74/176
; update layer progress
M73 L74
M991 S0 P73 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z9.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z9.8
G1 Z9.44
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.84 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z9.84
G1 Z9.44
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
M73 P37 R11
G1 E-.04 F1800
M204 S10000
G17
G3 Z9.84 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 9.6
; LAYER_HEIGHT: 0.160001
; layer num/total_layer_count: 75/176
; update layer progress
M73 L75
M991 S0 P74 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z9.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z9.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 9.72
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 76/176
; update layer progress
M73 L76
M991 S0 P75 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z10 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z10
G1 Z9.72
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.12 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z10.12
G1 Z9.72
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.12 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 9.8
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 77/176
; update layer progress
M73 L77
M991 S0 P76 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z9.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z9.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 78/176
; update layer progress
M73 L78
M991 S0 P77 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z10.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z10.2
G1 Z10
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
M73 P38 R11
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.4 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z10.4
G1 Z10
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.4 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z10.4
G1 Z10
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z10
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 79/176
; update layer progress
M73 L79
M991 S0 P78 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z10.4 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z10.4
G1 Z10.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
M73 P38 R10
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z10.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
M73 P39 R10
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10.28
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 80/176
; update layer progress
M73 L80
M991 S0 P79 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z10.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z10.6
G1 Z10.28
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.68 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z10.68
G1 Z10.28
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.68 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 10.4
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 81/176
; update layer progress
M73 L81
M991 S0 P80 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z10.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z10.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10.56
; LAYER_HEIGHT: 0.160001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 82/176
; update layer progress
M73 L82
M991 S0 P81 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z10.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z10.8
G1 Z10.56
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
M73 P40 R10
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.96 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z10.96
G1 Z10.56
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z10.96 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 10.6
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 83/176
; update layer progress
M73 L83
M991 S0 P82 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z10.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z10.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 84/176
; update layer progress
M73 L84
M991 S0 P83 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z11 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z11
G1 Z10.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z10.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 10.84
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 85/176
; update layer progress
M73 L85
M991 S0 P84 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z11.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z11.2
G1 Z10.84
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
M73 P41 R10
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.24 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z11.24
G1 Z10.84
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.24 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 11
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 86/176
; update layer progress
M73 L86
M991 S0 P85 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z11
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z11
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 11.12
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 87/176
; update layer progress
M73 L87
M991 S0 P86 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z11.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z11.4
G1 Z11.12
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.52 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z11.52
G1 Z11.12
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
M73 P42 R10
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.52 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 11.2
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 88/176
; update layer progress
M73 L88
M991 S0 P87 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z11.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z11.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 11.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 89/176
; update layer progress
M73 L89
M991 S0 P88 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z11.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z11.6
G1 Z11.4
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.8 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z11.8
G1 Z11.4
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.8 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z11.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z11.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 11.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 90/176
; update layer progress
M73 L90
M991 S0 P89 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z11.8 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z11.8
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
M73 P43 R10
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z11.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 11.68
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 91/176
; update layer progress
M73 L91
M991 S0 P90 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z12 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z12
G1 Z11.68
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.08 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z12.08
G1 Z11.68
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.08 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 11.8
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 92/176
; update layer progress
M73 L92
M991 S0 P91 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
M73 P44 R10
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z11.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 11.96
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 93/176
; update layer progress
M73 L93
M991 S0 P92 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z12.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z12.2
G1 Z11.96
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
M73 P44 R9
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.36 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z12.36
G1 Z11.96
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.36 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 12
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 94/176
; update layer progress
M73 L94
M991 S0 P93 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z12
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 12.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 95/176
; update layer progress
M73 L95
M991 S0 P94 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z12.4 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z12.4
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
M73 P45 R9
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z12.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 12.24
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 96/176
; update layer progress
M73 L96
M991 S0 P95 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z12.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z12.6
G1 Z12.24
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.64 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z12.64
G1 Z12.24
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.64 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 12.4
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 97/176
; update layer progress
M73 L97
M991 S0 P96 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z12.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 12.52
; LAYER_HEIGHT: 0.120001
; WIPE_START
G1 F15476.087
M73 P46 R9
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 98/176
; update layer progress
M73 L98
M991 S0 P97 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z12.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z12.8
G1 Z12.52
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.92 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z12.92
G1 Z12.52
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z12.92 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 12.6
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 99/176
; update layer progress
M73 L99
M991 S0 P98 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z12.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 12.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 100/176
; update layer progress
M73 L100
M991 S0 P99 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z13 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z13
G1 Z12.8
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.2 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z13.2
G1 Z12.8
G1 E.8 F1800
M73 P47 R9
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.2 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z12.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 101/176
; update layer progress
M73 L101
M991 S0 P100 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z13.2 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z13.2
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z13
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13.08
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 102/176
; update layer progress
M73 L102
M991 S0 P101 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z13.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z13.4
G1 Z13.08
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
M73 P48 R9
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.48 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z13.48
G1 Z13.08
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.48 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 13.2
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 103/176
; update layer progress
M73 L103
M991 S0 P102 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z13.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13.36
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 104/176
; update layer progress
M73 L104
M991 S0 P103 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z13.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z13.6
G1 Z13.36
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.76 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z13.76
G1 Z13.36
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
M73 P49 R9
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.76 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 13.4
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 105/176
; update layer progress
M73 L105
M991 S0 P104 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z13.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z13.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 106/176
; update layer progress
M73 L106
M991 S0 P105 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z13.8 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z13.8
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z13.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13.64
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 107/176
; update layer progress
M73 L107
M991 S0 P106 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z14 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z14
G1 Z13.64
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
M73 P49 R8
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
M73 P50 R8
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.04 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z14.04
G1 Z13.64
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.04 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 13.8
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 108/176
; update layer progress
M73 L108
M991 S0 P107 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z13.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z13.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 13.92
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 109/176
; update layer progress
M73 L109
M991 S0 P108 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z14.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z14.2
G1 Z13.92
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4985
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4985
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.32 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z14.32
G1 Z13.92
G1 E.8 F1800
G1 F4985
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.32 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 14
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 110/176
; update layer progress
M73 L110
M991 S0 P109 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4985
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4985
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
M73 P51 R8
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z14
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4985
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 14.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 111/176
; update layer progress
M73 L111
M991 S0 P110 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z14.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z14.4
G1 Z14.2
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.6 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z14.6
G1 Z14.2
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.6 I.304 J-1.178 P1  F42000
G1 X118.602 Y132.398 Z14.6
G1 Z14.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z14.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 14.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 112/176
; update layer progress
M73 L112
M991 S0 P111 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z14.6 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z14.6
G1 Z14.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
M73 P52 R8
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z14.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 14.48
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 113/176
; update layer progress
M73 L113
M991 S0 P112 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z14.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z14.8
G1 Z14.48
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.88 I.028 J-1.217 P1  F42000
G1 X107.86 Y131.066 Z14.88
G1 Z14.48
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z14.88 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 14.6
; LAYER_HEIGHT: 0.120001
; layer num/total_layer_count: 114/176
; update layer progress
M73 L114
M991 S0 P113 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z14.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z14.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 14.76
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 115/176
; update layer progress
M73 L115
M991 S0 P114 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z15 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z15
G1 Z14.76
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
M73 P53 R8
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z15.16 F42000
G1 X107.86 Y131.066 Z15.16
G1 Z14.76
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.16 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 14.8
; LAYER_HEIGHT: 0.04
; layer num/total_layer_count: 116/176
; update layer progress
M73 L116
M991 S0 P115 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z14.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z14.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 117/176
; update layer progress
M73 L117
M991 S0 P116 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z15.2 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z15.2
G1 Z15
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z15
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
M73 P54 R8
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15.04
; LAYER_HEIGHT: 0.04
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 118/176
; update layer progress
M73 L118
M991 S0 P117 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z15.4 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z15.4
G1 Z15.04
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z15.44 F42000
G1 X107.86 Y131.066 Z15.44
G1 Z15.04
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.44 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 15.2
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 119/176
; update layer progress
M73 L119
M991 S0 P118 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z15.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z15.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15.32
; LAYER_HEIGHT: 0.12
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 120/176
; update layer progress
M73 L120
M991 S0 P119 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z15.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z15.6
G1 Z15.32
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
M73 P55 R8
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z15.72 F42000
G1 X107.86 Y131.066 Z15.72
G1 Z15.32
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.72 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 15.4
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 121/176
; update layer progress
M73 L121
M991 S0 P120 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z15.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z15.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z15.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 122/176
; update layer progress
M73 L122
M991 S0 P121 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z15.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z15.8
G1 Z15.6
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4965
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4965
M204 S6000
G1 X148.14 Y116.492 E1.65384
M73 P55 R7
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z16 F42000
G1 X107.86 Y131.066 Z16
G1 Z15.6
G1 E.8 F1800
G1 F4965
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.75 Y137.6 Z16 F42000
G1 X118.602 Y132.398 Z16
G1 Z15.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4965
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
M73 P56 R7
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4965
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z15.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4965
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 123/176
; update layer progress
M73 L123
M991 S0 P122 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z16 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z16
G1 Z15.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z15.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 15.88
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 124/176
; update layer progress
M73 L124
M991 S0 P123 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z16.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z16.2
G1 Z15.88
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z16.28 F42000
G1 X107.86 Y131.066 Z16.28
G1 Z15.88
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
M73 P57 R7
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.28 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 16
; LAYER_HEIGHT: 0.12
; layer num/total_layer_count: 125/176
; update layer progress
M73 L125
M991 S0 P124 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z16
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z16
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 16.16
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 126/176
; update layer progress
M73 L126
M991 S0 P125 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z16.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z16.4
G1 Z16.16
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z16.56 F42000
G1 X107.86 Y131.066 Z16.56
G1 Z16.16
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.56 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 16.2
; LAYER_HEIGHT: 0.0400009
; layer num/total_layer_count: 127/176
; update layer progress
M73 L127
M991 S0 P126 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z16.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z16.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 16.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
M73 P58 R7
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 128/176
; update layer progress
M73 L128
M991 S0 P127 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z16.6 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z16.6
G1 Z16.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z16.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 16.44
; LAYER_HEIGHT: 0.0400009
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 129/176
; update layer progress
M73 L129
M991 S0 P128 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z16.8 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z16.8
G1 Z16.44
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z16.84 F42000
G1 X107.86 Y131.066 Z16.84
G1 Z16.44
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
M73 P59 R7
G1 E-.04 F1800
M204 S10000
G17
G3 Z16.84 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 16.6
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 130/176
; update layer progress
M73 L130
M991 S0 P129 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z16.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z16.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 16.72
; LAYER_HEIGHT: 0.119999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 131/176
; update layer progress
M73 L131
M991 S0 P130 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z17 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z17
G1 Z16.72
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z17.12 F42000
G1 X107.86 Y131.066 Z17.12
G1 Z16.72
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.12 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 16.8
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 132/176
; update layer progress
M73 L132
M991 S0 P131 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z16.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z16.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 133/176
; update layer progress
M73 L133
M991 S0 P132 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z17.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z17.2
G1 Z17
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4956
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4956
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
M73 P60 R7
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z17.4 F42000
G1 X107.86 Y131.066 Z17.4
G1 Z17
G1 E.8 F1800
G1 F4956
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.75 Y137.6 Z17.4 F42000
G1 X118.602 Y132.398 Z17.4
G1 Z17
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4956
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4956
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z17
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4956
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 134/176
; update layer progress
M73 L134
M991 S0 P133 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z17.4 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z17.4
G1 Z17.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z17.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
M73 P61 R7
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17.28
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 135/176
; update layer progress
M73 L135
M991 S0 P134 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z17.6 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z17.6
G1 Z17.28
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
M73 P61 R6
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z17.68 F42000
G1 X107.86 Y131.066 Z17.68
G1 Z17.28
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.68 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 17.4
; LAYER_HEIGHT: 0.119999
; layer num/total_layer_count: 136/176
; update layer progress
M73 L136
M991 S0 P135 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z17.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z17.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17.56
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 137/176
; update layer progress
M73 L137
M991 S0 P136 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z17.8 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z17.8
G1 Z17.56
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
M73 P62 R6
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z17.96 F42000
G1 X107.86 Y131.066 Z17.96
G1 Z17.56
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z17.96 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 17.6
; LAYER_HEIGHT: 0.0400009
; layer num/total_layer_count: 138/176
; update layer progress
M73 L138
M991 S0 P137 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z17.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z17.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 139/176
; update layer progress
M73 L139
M991 S0 P138 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z18 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z18
G1 Z17.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z17.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 17.84
; LAYER_HEIGHT: 0.0400009
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 140/176
; update layer progress
M73 L140
M991 S0 P139 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z18.2 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z18.2
G1 Z17.84
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
M73 P63 R6
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z18.24 F42000
G1 X107.86 Y131.066 Z18.24
G1 Z17.84
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.24 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 18
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 141/176
; update layer progress
M73 L141
M991 S0 P140 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z18
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z18
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 18.12
; LAYER_HEIGHT: 0.120001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 142/176
; update layer progress
M73 L142
M991 S0 P141 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z18.4 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z18.4
G1 Z18.12
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z18.52 F42000
G1 X107.86 Y131.066 Z18.52
G1 Z18.12
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
M73 P64 R6
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.52 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 18.2
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 143/176
; update layer progress
M73 L143
M991 S0 P142 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z18.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z18.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 18.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 144/176
; update layer progress
M73 L144
M991 S0 P143 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z18.6 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z18.6
G1 Z18.4
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4965
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4965
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z18.8 F42000
G1 X107.86 Y131.066 Z18.8
G1 Z18.4
G1 E.8 F1800
G1 F4965
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X138.75 Y137.6 Z18.8 F42000
G1 X118.602 Y132.398 Z18.8
G1 Z18.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4965
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F4965
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z18.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z18.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4965
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 18.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 145/176
; update layer progress
M73 L145
M991 S0 P144 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z18.8 I-1.196 J-.222 P1  F42000
G1 X118.602 Y132.398 Z18.8
G1 Z18.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
M73 P65 R6
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z18.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 18.68
; LAYER_HEIGHT: 0.0799999
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 146/176
; update layer progress
M73 L146
M991 S0 P145 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z19 I-1.185 J-.275 P1  F42000
G1 X117.691 Y133.452 Z19
G1 Z18.68
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4975
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4975
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z19.08 F42000
G1 X107.86 Y131.066 Z19.08
G1 Z18.68
G1 E.8 F1800
G1 F4975
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.08 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 18.8
; LAYER_HEIGHT: 0.119999
; layer num/total_layer_count: 147/176
; update layer progress
M73 L147
M991 S0 P146 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z18.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4975
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
M73 P66 R6
G1 F4975
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z18.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4975
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 18.96
; LAYER_HEIGHT: 0.16
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 148/176
; update layer progress
M73 L148
M991 S0 P147 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z19.2 I-1.148 J-.403 P1  F42000
G1 X117.691 Y133.452 Z19.2
G1 Z18.96
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4966
M204 S6000
G1 X117.461 Y133.223 E.01332
G1 X117.461 Y130.877 E.09633
G1 X107.86 Y130.877 E.39421
G1 X107.86 Y128 E.11813
G1 X117.461 Y128 E.39421
G1 X117.461 Y125.123 E.11813
G1 X107.86 Y125.123 E.39421
G1 X107.86 Y122.434 E.11039
M204 S10000
G1 X107.86 Y116.492 F42000
G1 F4966
M204 S6000
G1 X148.14 Y116.492 E1.65384
G1 X148.14 Y119.369 E.11813
G1 X107.86 Y119.369 E1.65384
G1 X107.86 Y122.246 E.11813
G1 X148.14 Y122.246 E1.65384
G1 X148.14 Y125.123 E.11813
G1 X128.539 Y125.123 E.80481
G1 X128.539 Y128 E.11813
G1 X148.14 Y128 E.80481
G1 X148.14 Y130.877 E.11813
G1 X128.539 Y130.877 E.80481
G1 X128.539 Y133.223 E.09633
G1 X128.309 Y133.452 E.01332
; WIPE_START
G1 F9000
G1 X128.539 Y133.223 E-.12328
G1 X128.539 Y131.547 E-.63672
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X120.908 Y131.37 Z19.36 F42000
G1 X107.86 Y131.066 Z19.36
G1 Z18.96
G1 E.8 F1800
G1 F4966
M204 S6000
G1 X107.86 Y133.754 E.11039
G1 X148.14 Y133.754 E1.65384
G1 X148.14 Y136.631 E.11813
G1 X107.86 Y136.631 E1.65384
G1 X107.86 Y139.508 E.11813
G1 X148.14 Y139.508 E1.65384
; WIPE_START
G1 F9000
G1 X146.14 Y139.508 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.36 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 19
; LAYER_HEIGHT: 0.0400009
; layer num/total_layer_count: 149/176
; update layer progress
M73 L149
M991 S0 P148 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z19
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F4966
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
M73 P66 R5
G1 F4966
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z19
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F4966
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 19.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 150/176
; update layer progress
M73 L150
M991 S0 P149 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z19.4 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z19.4
G1 Z19.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
M73 P67 R5
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z19.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 19.24
; LAYER_HEIGHT: 0.039999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 151/176
; update layer progress
M73 L151
M991 S0 P150 ;notify layer change
M106 S191.25
; OBJECT_ID: 15
M204 S10000
G17
G3 Z19.6 I-1.139 J-.429 P1  F42000
G1 X117.608 Y133.37 Z19.6
G1 Z19.24
G1 E.8 F1800
; FEATURE: Support transition
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F3000
M204 S6000
G1 X117.777 Y133.538 E.00979
G1 X118.352 Y133.538 E.02362
G1 X118.352 Y139.509 E.24513
G1 X119.229 Y139.509 E.03601
G1 X119.229 Y133.538 E.24513
G1 X120.106 Y133.538 E.03601
G1 X120.106 Y139.509 E.24513
G1 X120.983 Y139.509 E.03601
G1 X120.983 Y133.538 E.24513
G1 X121.861 Y133.538 E.03601
G1 X121.861 Y139.509 E.24513
G1 X122.738 Y139.509 E.03601
G1 X122.738 Y133.538 E.24513
G1 X123.615 Y133.538 E.03601
G1 X123.615 Y139.509 E.24513
G1 X124.492 Y139.509 E.03601
G1 X124.492 Y133.538 E.24513
G1 X125.369 Y133.538 E.03601
G1 X125.369 Y139.509 E.24513
G1 X126.246 Y139.509 E.03601
G1 X126.246 Y133.538 E.24513
G1 X127.123 Y133.538 E.03601
G1 X127.123 Y139.509 E.24513
G1 X128 Y139.509 E.03601
G1 X128 Y133.538 E.24513
G1 X128.223 Y133.538 E.00916
G1 X128.538 Y133.223 E.01831
G1 X128.538 Y122.777 E.42891
G1 X128.223 Y122.462 E.01831
G1 X128 Y122.462 E.00916
G1 X128 Y116.492 E.24513
G1 X128.877 Y116.492 E.03601
G1 X128.877 Y139.509 E.94506
G1 X129.754 Y139.509 E.03601
G1 X129.754 Y116.492 E.94506
G1 X130.631 Y116.492 E.03601
G1 X130.631 Y139.509 E.94506
G1 X131.508 Y139.509 E.03601
G1 X131.508 Y116.492 E.94506
G1 X132.385 Y116.492 E.03601
G1 X132.385 Y139.509 E.94506
G1 X133.262 Y139.509 E.03601
G1 X133.262 Y116.492 E.94506
G1 X134.139 Y116.492 E.03601
G1 X134.139 Y139.509 E.94506
G1 X135.017 Y139.509 E.03601
G1 X135.017 Y116.492 E.94506
G1 X135.894 Y116.492 E.03601
G1 X135.894 Y139.509 E.94506
G1 X136.771 Y139.509 E.03601
G1 X136.771 Y116.492 E.94506
G1 X137.648 Y116.492 E.03601
G1 X137.648 Y139.509 E.94506
M73 P68 R5
G1 X138.525 Y139.509 E.03601
G1 X138.525 Y116.492 E.94506
G1 X139.402 Y116.492 E.03601
G1 X139.402 Y139.509 E.94506
G1 X140.279 Y139.509 E.03601
G1 X140.279 Y116.492 E.94506
G1 X141.156 Y116.492 E.03601
G1 X141.156 Y139.509 E.94506
G1 X142.033 Y139.509 E.03601
G1 X142.033 Y116.492 E.94506
G1 X142.91 Y116.492 E.03601
G1 X142.91 Y139.509 E.94506
G1 X143.787 Y139.509 E.03601
G1 X143.787 Y116.492 E.94506
G1 X144.664 Y116.492 E.03601
G1 X144.664 Y139.509 E.94506
G1 X145.541 Y139.509 E.03601
G1 X145.541 Y116.492 E.94506
G1 X146.418 Y116.492 E.03601
G1 X146.418 Y139.509 E.94506
G1 X147.296 Y139.509 E.03601
G1 X147.296 Y116.492 E.94506
G1 X148.14 Y116.492 E.03466
G1 X148.14 Y139.509 E.94506
G1 X147.484 Y139.509 E.02692
M204 S10000
G1 X127.811 Y116.492 F42000
G1 F3000
M204 S6000
G1 X127.123 Y116.492 E.02827
G1 X127.123 Y122.462 E.24513
G1 X126.246 Y122.462 E.03601
G1 X126.246 Y116.492 E.24513
G1 X125.369 Y116.492 E.03601
G1 X125.369 Y122.462 E.24513
G1 X124.492 Y122.462 E.03601
G1 X124.492 Y116.492 E.24513
G1 X123.615 Y116.492 E.03601
G1 X123.615 Y122.462 E.24513
G1 X122.738 Y122.462 E.03601
G1 X122.738 Y116.492 E.24513
G1 X121.861 Y116.492 E.03601
G1 X121.861 Y122.462 E.24513
G1 X120.983 Y122.462 E.03601
G1 X120.983 Y116.492 E.24513
G1 X120.106 Y116.492 E.03601
G1 X120.106 Y122.462 E.24513
G1 X119.229 Y122.462 E.03601
G1 X119.229 Y116.492 E.24513
G1 X118.352 Y116.492 E.03601
G1 X118.352 Y122.462 E.24513
G1 X117.777 Y122.462 E.02362
G1 X117.608 Y122.63 E.00979
M204 S10000
G1 X118.164 Y116.492 F42000
G1 F3000
M204 S6000
G1 X117.475 Y116.492 E.02827
G1 X117.475 Y139.509 E.94506
G1 X116.598 Y139.509 E.03601
G1 X116.598 Y116.492 E.94506
G1 X115.721 Y116.492 E.03601
G1 X115.721 Y139.509 E.94506
G1 X114.844 Y139.509 E.03601
G1 X114.844 Y116.492 E.94506
G1 X113.967 Y116.492 E.03601
G1 X113.967 Y139.509 E.94506
G1 X113.09 Y139.509 E.03601
G1 X113.09 Y116.492 E.94506
G1 X112.213 Y116.492 E.03601
G1 X112.213 Y139.509 E.94506
M73 P69 R5
G1 X111.336 Y139.509 E.03601
G1 X111.336 Y116.492 E.94506
G1 X110.459 Y116.492 E.03601
G1 X110.459 Y139.509 E.94506
G1 X109.582 Y139.509 E.03601
G1 X109.582 Y116.492 E.94506
G1 X108.704 Y116.492 E.03601
G1 X108.704 Y139.509 E.94506
G1 X107.86 Y139.509 E.03466
G1 X107.86 Y116.492 E.94506
G1 X108.516 Y116.492 E.02692
; WIPE_START
G1 X107.86 Y116.492 E-.24911
G1 X107.86 Y117.836 E-.51089
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.64 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 19.4
; LAYER_HEIGHT: 0.16
; layer num/total_layer_count: 152/176
; update layer progress
M73 L152
M991 S0 P151 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z19.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z19.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 19.52
; LAYER_HEIGHT: 0.120001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 153/176
; update layer progress
M73 L153
M991 S0 P152 ;notify layer change
M106 S198.9
; OBJECT_ID: 15
M204 S10000
G17
G3 Z19.8 I-1.192 J-.244 P1  F42000
G1 X116.598 Y139.678 Z19.8
G1 Z19.52
G1 E.8 F1800
; FEATURE: Support interface
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4800
M204 S6000
G1 X116.598 Y116.492 E.95203
G1 X115.721 Y116.492 E.03601
G1 X115.721 Y139.509 E.94506
G1 X114.844 Y139.509 E.03601
G1 X114.844 Y116.492 E.94506
G1 X113.967 Y116.492 E.03601
G1 X113.967 Y139.509 E.94506
G1 X113.09 Y139.509 E.03601
G1 X113.09 Y116.492 E.94506
G1 X112.213 Y116.492 E.03601
G1 X112.213 Y139.509 E.94506
G1 X111.336 Y139.509 E.03601
G1 X111.336 Y116.492 E.94506
G1 X110.459 Y116.492 E.03601
G1 X110.459 Y139.509 E.94506
G1 X109.582 Y139.509 E.03601
G1 X109.582 Y116.492 E.94506
G1 X108.704 Y116.492 E.03601
G1 X108.704 Y139.678 E.95203
; WIPE_START
G1 X108.704 Y137.678 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X113.821 Y132.015 Z19.92 F42000
G1 X128 Y116.322 Z19.92
G1 Z19.52
G1 E.8 F1800
G1 F4800
M204 S6000
G1 X128 Y122.462 E.25209
G1 X127.123 Y122.462 E.03601
G1 X127.123 Y116.492 E.24513
G1 X126.246 Y116.492 E.03601
G1 X126.246 Y122.462 E.24513
G1 X125.369 Y122.462 E.03601
G1 X125.369 Y116.492 E.24513
G1 X124.492 Y116.492 E.03601
G1 X124.492 Y122.462 E.24513
G1 X123.615 Y122.462 E.03601
G1 X123.615 Y116.492 E.24513
G1 X122.738 Y116.492 E.03601
G1 X122.738 Y122.462 E.24513
G1 X121.861 Y122.462 E.03601
G1 X121.861 Y116.492 E.24513
G1 X120.983 Y116.492 E.03601
G1 X120.983 Y122.462 E.24513
G1 X120.106 Y122.462 E.03601
G1 X120.106 Y116.492 E.24513
G1 X119.229 Y116.492 E.03601
G1 X119.229 Y122.462 E.24513
G1 X118.352 Y122.462 E.03601
G1 X118.352 Y116.492 E.24513
G1 X117.475 Y116.492 E.03601
G1 X117.475 Y139.509 E.94506
G1 X118.352 Y139.509 E.03601
G1 X118.352 Y133.538 E.24513
G1 X119.229 Y133.538 E.03601
G1 X119.229 Y139.509 E.24513
G1 X120.106 Y139.509 E.03601
G1 X120.106 Y133.538 E.24513
G1 X120.983 Y133.538 E.03601
G1 X120.983 Y139.509 E.24513
G1 X121.861 Y139.509 E.03601
G1 X121.861 Y133.538 E.24513
G1 X122.738 Y133.538 E.03601
G1 X122.738 Y139.509 E.24513
G1 X123.615 Y139.509 E.03601
G1 X123.615 Y133.538 E.24513
G1 X124.492 Y133.538 E.03601
G1 X124.492 Y139.509 E.24513
M73 P70 R5
G1 X125.369 Y139.509 E.03601
G1 X125.369 Y133.538 E.24513
G1 X126.246 Y133.538 E.03601
G1 X126.246 Y139.509 E.24513
G1 X127.123 Y139.509 E.03601
G1 X127.123 Y133.538 E.24513
G1 X128 Y133.538 E.03601
G1 X128 Y139.509 E.24513
G1 X128.877 Y139.509 E.03601
G1 X128.877 Y116.492 E.94506
G1 X129.754 Y116.492 E.03601
G1 X129.754 Y139.509 E.94506
G1 X130.631 Y139.509 E.03601
G1 X130.631 Y116.492 E.94506
G1 X131.508 Y116.492 E.03601
G1 X131.508 Y139.509 E.94506
G1 X132.385 Y139.509 E.03601
G1 X132.385 Y116.492 E.94506
G1 X133.262 Y116.492 E.03601
G1 X133.262 Y139.509 E.94506
G1 X134.139 Y139.509 E.03601
G1 X134.139 Y116.492 E.94506
G1 X135.017 Y116.492 E.03601
G1 X135.017 Y139.509 E.94506
G1 X135.894 Y139.509 E.03601
G1 X135.894 Y116.492 E.94506
G1 X136.771 Y116.492 E.03601
G1 X136.771 Y139.509 E.94506
G1 X137.648 Y139.509 E.03601
G1 X137.648 Y116.492 E.94506
G1 X138.525 Y116.492 E.03601
G1 X138.525 Y139.509 E.94506
G1 X139.402 Y139.509 E.03601
G1 X139.402 Y116.492 E.94506
G1 X140.279 Y116.492 E.03601
G1 X140.279 Y139.509 E.94506
G1 X141.156 Y139.509 E.03601
G1 X141.156 Y116.492 E.94506
G1 X142.033 Y116.492 E.03601
G1 X142.033 Y139.509 E.94506
G1 X142.91 Y139.509 E.03601
G1 X142.91 Y116.492 E.94506
G1 X143.787 Y116.492 E.03601
G1 X143.787 Y139.509 E.94506
G1 X144.664 Y139.509 E.03601
G1 X144.664 Y116.492 E.94506
G1 X145.541 Y116.492 E.03601
G1 X145.541 Y139.509 E.94506
G1 X146.418 Y139.509 E.03601
G1 X146.418 Y116.492 E.94506
G1 X147.296 Y116.492 E.03601
G1 X147.296 Y139.678 E.95203
; WIPE_START
G1 X147.296 Y137.678 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z19.92 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

; CHANGE_LAYER
; Z_HEIGHT: 19.6
; LAYER_HEIGHT: 0.0799999
; layer num/total_layer_count: 154/176
; update layer progress
M73 L154
M991 S0 P153 ;notify layer change
; OBJECT_ID: 15
G1 X118.602 Y132.398
G1 Z19.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z19.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 19.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 155/176
; update layer progress
M73 L155
M991 S0 P154 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z20 I-1.181 J-.292 P1  F42000
G1 X116.598 Y139.678 Z20
G1 Z19.8
G1 E.8 F1800
; FEATURE: Support interface
; LINE_WIDTH: 0.42
; LAYER_HEIGHT: 0.28
G1 F4800
M204 S6000
G1 X116.598 Y116.492 E.95203
G1 X115.721 Y116.492 E.03601
G1 X115.721 Y139.509 E.94506
G1 X114.844 Y139.509 E.03601
G1 X114.844 Y116.492 E.94506
G1 X113.967 Y116.492 E.03601
G1 X113.967 Y139.509 E.94506
G1 X113.09 Y139.509 E.03601
G1 X113.09 Y116.492 E.94506
G1 X112.213 Y116.492 E.03601
G1 X112.213 Y139.509 E.94506
M73 P71 R5
G1 X111.336 Y139.509 E.03601
G1 X111.336 Y116.492 E.94506
G1 X110.459 Y116.492 E.03601
G1 X110.459 Y139.509 E.94506
G1 X109.582 Y139.509 E.03601
G1 X109.582 Y116.492 E.94506
G1 X108.704 Y116.492 E.03601
G1 X108.704 Y139.678 E.95203
; WIPE_START
G1 X108.704 Y137.678 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X113.821 Y132.015 Z20.2 F42000
G1 X128 Y116.322 Z20.2
G1 Z19.8
G1 E.8 F1800
G1 F4800
M204 S6000
G1 X128 Y122.462 E.25209
G1 X127.123 Y122.462 E.03601
G1 X127.123 Y116.492 E.24513
G1 X126.246 Y116.492 E.03601
G1 X126.246 Y122.462 E.24513
G1 X125.369 Y122.462 E.03601
G1 X125.369 Y116.492 E.24513
G1 X124.492 Y116.492 E.03601
G1 X124.492 Y122.462 E.24513
G1 X123.615 Y122.462 E.03601
G1 X123.615 Y116.492 E.24513
G1 X122.738 Y116.492 E.03601
G1 X122.738 Y122.462 E.24513
G1 X121.861 Y122.462 E.03601
G1 X121.861 Y116.492 E.24513
G1 X120.983 Y116.492 E.03601
G1 X120.983 Y122.462 E.24513
G1 X120.106 Y122.462 E.03601
G1 X120.106 Y116.492 E.24513
G1 X119.229 Y116.492 E.03601
G1 X119.229 Y122.462 E.24513
G1 X118.352 Y122.462 E.03601
G1 X118.352 Y116.492 E.24513
G1 X117.475 Y116.492 E.03601
G1 X117.475 Y139.509 E.94506
G1 X118.352 Y139.509 E.03601
G1 X118.352 Y133.538 E.24513
G1 X119.229 Y133.538 E.03601
G1 X119.229 Y139.509 E.24513
G1 X120.106 Y139.509 E.03601
G1 X120.106 Y133.538 E.24513
G1 X120.983 Y133.538 E.03601
G1 X120.983 Y139.509 E.24513
G1 X121.861 Y139.509 E.03601
G1 X121.861 Y133.538 E.24513
G1 X122.738 Y133.538 E.03601
G1 X122.738 Y139.509 E.24513
G1 X123.615 Y139.509 E.03601
G1 X123.615 Y133.538 E.24513
G1 X124.492 Y133.538 E.03601
G1 X124.492 Y139.509 E.24513
G1 X125.369 Y139.509 E.03601
G1 X125.369 Y133.538 E.24513
G1 X126.246 Y133.538 E.03601
G1 X126.246 Y139.509 E.24513
G1 X127.123 Y139.509 E.03601
G1 X127.123 Y133.538 E.24513
G1 X128 Y133.538 E.03601
G1 X128 Y139.509 E.24513
G1 X128.877 Y139.509 E.03601
G1 X128.877 Y116.492 E.94506
G1 X129.754 Y116.492 E.03601
G1 X129.754 Y139.509 E.94506
G1 X130.631 Y139.509 E.03601
G1 X130.631 Y116.492 E.94506
G1 X131.508 Y116.492 E.03601
G1 X131.508 Y139.509 E.94506
G1 X132.385 Y139.509 E.03601
G1 X132.385 Y116.492 E.94506
G1 X133.262 Y116.492 E.03601
G1 X133.262 Y139.509 E.94506
G1 X134.139 Y139.509 E.03601
G1 X134.139 Y116.492 E.94506
G1 X135.017 Y116.492 E.03601
G1 X135.017 Y139.509 E.94506
G1 X135.894 Y139.509 E.03601
G1 X135.894 Y116.492 E.94506
G1 X136.771 Y116.492 E.03601
G1 X136.771 Y139.509 E.94506
G1 X137.648 Y139.509 E.03601
G1 X137.648 Y116.492 E.94506
G1 X138.525 Y116.492 E.03601
G1 X138.525 Y139.509 E.94506
G1 X139.402 Y139.509 E.03601
G1 X139.402 Y116.492 E.94506
G1 X140.279 Y116.492 E.03601
G1 X140.279 Y139.509 E.94506
G1 X141.156 Y139.509 E.03601
G1 X141.156 Y116.492 E.94506
G1 X142.033 Y116.492 E.03601
G1 X142.033 Y139.509 E.94506
G1 X142.91 Y139.509 E.03601
G1 X142.91 Y116.492 E.94506
G1 X143.787 Y116.492 E.03601
G1 X143.787 Y139.509 E.94506
G1 X144.664 Y139.509 E.03601
G1 X144.664 Y116.492 E.94506
G1 X145.541 Y116.492 E.03601
G1 X145.541 Y139.509 E.94506
M73 P72 R5
G1 X146.418 Y139.509 E.03601
G1 X146.418 Y116.492 E.94506
G1 X147.296 Y116.492 E.03601
G1 X147.296 Y139.678 E.95203
; WIPE_START
G1 X147.296 Y137.678 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X139.789 Y136.297 Z20.2 F42000
G1 X118.602 Y132.398 Z20.2
G1 Z19.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
; LAYER_HEIGHT: 0.2
G1 F15476.087
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y131.002
G1 Z19.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X118.95 Y129.374 E.05401
G1 X124.374 Y123.95 E.25442
G1 X123.95 Y123.95 E.01404
G1 X127.05 Y127.05 E.1454
G1 X127.05 Y128.95 E.06305
G1 X123.95 Y132.05 E.1454
G1 X124.374 Y132.05 E.01405
M73 P72 R4
G1 X118.95 Y126.626 E.25442
G1 X118.95 Y124.998 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 20
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y126.626 E-.61876
G1 X119.213 Y126.889 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 156/176
; update layer progress
M73 L156
M991 S0 P155 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
G3 Z20.2 I-1.21 J-.134 P1  F42000
G1 X118.602 Y132.398 Z20.2
G1 Z20
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X118.602 Y123.602 E.29178
G1 X127.398 Y123.602 E.29178
G1 X127.398 Y132.398 E.29178
G1 X118.662 Y132.398 E.28978
M204 S250
G1 X118.21 Y132.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X118.21 Y123.21 E.29437
G1 X127.79 Y123.21 E.29437
G1 X127.79 Y132.79 E.29437
G1 X118.27 Y132.79 E.29252
; WIPE_START
G1 F12000
M204 S6000
G1 X118.257 Y130.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X118.95 Y124.998
G1 Z20
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X118.95 Y126.626 E.05401
G1 X124.374 Y132.05 E.25442
G1 X123.95 Y132.05 E.01405
G1 X127.05 Y128.95 E.1454
G1 X127.05 Y127.05 E.06305
G1 X123.95 Y123.95 E.1454
G1 X124.374 Y123.95 E.01404
G1 X118.95 Y129.374 E.25442
G1 X118.95 Y131.002 E.05401
M106 S255
; CHANGE_LAYER
; Z_HEIGHT: 20.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X118.95 Y129.374 E-.61876
G1 X119.213 Y129.111 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 157/176
; update layer progress
M73 L157
M991 S0 P156 ;notify layer change
M106 S255
; OBJECT_ID: 15
M204 S10000
G17
G3 Z20.4 I-.835 J.885 P1  F42000
G1 X128 Y137.398 Z20.4
G1 Z20.2
G1 E.8 F1800
; FEATURE: Overhang wall
G1 F600
M204 S5000
G1 X108.602 Y137.398 E.64346
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
M73 P73 R4
G1 X128.06 Y137.398 E.64148
M106 S165.75
M106 S255
M204 S250
G1 X128 Y137.79 F42000
G1 F600
M204 S5000
G1 X108.21 Y137.79 E.65647
G1 X108.21 Y118.21 E.64951
G1 X147.79 Y118.21 E1.31294
M73 P74 R4
G1 X147.79 Y137.79 E.64951
G1 X128.06 Y137.79 E.65448
M106 S165.75
M106 S255
; WIPE_START
M204 S6000
G1 X126.06 Y137.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X119.03 Y130.923
G1 Z20.2
G1 E.8 F1800
; FEATURE: Sparse infill
G1 F15476.087
M204 S6000
M73 P75 R4
G1 X119.03 Y129.294 E.05401
G1 X124.294 Y124.03 E.24698
G1 X124.03 Y124.03 E.00878
G1 X126.97 Y126.97 E.13796
G1 X126.97 Y129.03 E.06831
G1 X124.03 Y131.97 E.13796
G1 X124.294 Y131.97 E.00879
G1 X119.03 Y126.706 E.24698
G1 X119.03 Y125.077 E.05401
; WIPE_START
G1 X119.03 Y126.706 E-.61876
G1 X119.292 Y126.968 E-.14125
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.6 I-.842 J-.878 P1  F42000
G1 X108.766 Y137.064 Z20.6
G1 Z20.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.4206
G1 F3000
M204 S6000
G1 X147.065 Y137.064 E1.1787
G1 X147.065 Y136.687 E.01162
G1 X108.935 Y136.687 E1.17347
G1 X108.935 Y136.309 E.01162
G1 X147.065 Y136.309 E1.17347
G1 X147.065 Y135.931 E.01162
G1 X108.935 Y135.931 E1.17347
G1 X108.935 Y135.554 E.01162
G1 X147.065 Y135.554 E1.17347
G1 X147.065 Y135.176 E.01162
G1 X108.935 Y135.176 E1.17347
G1 X108.935 Y134.798 E.01162
G1 X147.065 Y134.798 E1.17347
G1 X147.065 Y134.421 E.01162
G1 X108.935 Y134.421 E1.17347
G1 X108.935 Y134.043 E.01162
G1 X147.065 Y134.043 E1.17347
G1 X147.065 Y133.665 E.01162
G1 X108.935 Y133.665 E1.17347
G1 X108.935 Y133.288 E.01162
G1 X147.065 Y133.288 E1.17347
G1 X147.065 Y132.91 E.01162
G1 X108.935 Y132.91 E1.17347
G1 X108.935 Y132.532 E.01162
G1 X147.234 Y132.532 E1.1787
M106 S165.75
M106 S255
; WIPE_START
G1 X145.234 Y132.532 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.6 I1.186 J.273 P1  F42000
M73 P76 R4
G1 X147.234 Y123.846 Z20.6
G1 Z20.2
G1 E.8 F1800
G1 F3000
M204 S6000
G1 X127.363 Y123.846 E.61158
G1 X127.363 Y124.223 E.01162
G1 X147.065 Y124.223 E.60636
G1 X147.065 Y124.601 E.01162
G1 X127.363 Y124.601 E.60636
G1 X127.363 Y124.979 E.01162
G1 X147.065 Y124.979 E.60636
G1 X147.065 Y125.356 E.01162
G1 X127.363 Y125.356 E.60636
G1 X127.363 Y125.734 E.01162
G1 X147.065 Y125.734 E.60636
G1 X147.065 Y126.112 E.01162
G1 X127.363 Y126.112 E.60636
G1 X127.363 Y126.489 E.01162
G1 X147.065 Y126.489 E.60636
G1 X147.065 Y126.867 E.01162
G1 X127.363 Y126.867 E.60636
G1 X127.363 Y127.245 E.01162
G1 X147.065 Y127.245 E.60636
G1 X147.065 Y127.622 E.01162
G1 X127.363 Y127.622 E.60636
G1 X127.363 Y128 E.01162
G1 X147.065 Y128 E.60636
G1 X147.065 Y128.378 E.01162
G1 X127.363 Y128.378 E.60636
G1 X127.363 Y128.755 E.01162
G1 X147.065 Y128.755 E.60636
G1 X147.065 Y129.133 E.01162
G1 X127.363 Y129.133 E.60636
G1 X127.363 Y129.511 E.01162
G1 X147.065 Y129.511 E.60636
G1 X147.065 Y129.888 E.01162
G1 X127.363 Y129.888 E.60636
G1 X127.363 Y130.266 E.01162
G1 X147.065 Y130.266 E.60636
G1 X147.065 Y130.644 E.01162
G1 X127.363 Y130.644 E.60636
G1 X127.363 Y131.021 E.01162
G1 X147.065 Y131.021 E.60636
G1 X147.065 Y131.399 E.01162
G1 X127.363 Y131.399 E.60636
G1 X127.363 Y131.777 E.01162
G1 X147.065 Y131.777 E.60636
G1 X147.065 Y132.154 E.01162
G1 X127.363 Y132.154 E.60636
G1 X127.159 Y132.363 E.00895
G1 X118.841 Y132.363 E.25602
G1 X118.637 Y132.154 E.00895
G1 X108.935 Y132.154 E.29859
G1 X108.935 Y131.777 E.01162
G1 X118.637 Y131.777 E.29859
G1 X118.637 Y131.399 E.01162
G1 X108.935 Y131.399 E.29859
G1 X108.935 Y131.021 E.01162
G1 X118.637 Y131.021 E.29859
G1 X118.637 Y130.644 E.01162
G1 X108.935 Y130.644 E.29859
G1 X108.935 Y130.266 E.01162
G1 X118.637 Y130.266 E.29859
M73 P77 R4
G1 X118.637 Y129.888 E.01162
G1 X108.935 Y129.888 E.29859
G1 X108.935 Y129.511 E.01162
G1 X118.637 Y129.511 E.29859
G1 X118.637 Y129.133 E.01162
G1 X108.935 Y129.133 E.29859
G1 X108.935 Y128.755 E.01162
G1 X118.637 Y128.755 E.29859
G1 X118.637 Y128.378 E.01162
G1 X108.935 Y128.378 E.29859
G1 X108.935 Y128 E.01162
G1 X118.637 Y128 E.29859
G1 X118.637 Y127.622 E.01162
G1 X108.935 Y127.622 E.29859
G1 X108.935 Y127.245 E.01162
G1 X118.637 Y127.245 E.29859
G1 X118.637 Y126.867 E.01162
G1 X108.935 Y126.867 E.29859
G1 X108.935 Y126.489 E.01162
G1 X118.637 Y126.489 E.29859
G1 X118.637 Y126.112 E.01162
G1 X108.935 Y126.112 E.29859
G1 X108.935 Y125.734 E.01162
G1 X118.637 Y125.734 E.29859
G1 X118.637 Y125.356 E.01162
G1 X108.935 Y125.356 E.29859
G1 X108.935 Y124.979 E.01162
G1 X118.637 Y124.979 E.29859
G1 X118.637 Y124.601 E.01162
G1 X108.935 Y124.601 E.29859
G1 X108.935 Y124.223 E.01162
G1 X118.637 Y124.223 E.29859
G1 X118.637 Y123.846 E.01162
G1 X108.935 Y123.846 E.29859
G1 X108.935 Y123.468 E.01162
G1 X147.065 Y123.468 E1.17347
G1 X147.065 Y123.09 E.01162
G1 X108.935 Y123.09 E1.17347
G1 X108.935 Y122.712 E.01162
G1 X147.065 Y122.712 E1.17347
G1 X147.065 Y122.335 E.01162
G1 X108.935 Y122.335 E1.17347
G1 X108.935 Y121.957 E.01162
G1 X147.065 Y121.957 E1.17347
G1 X147.065 Y121.579 E.01162
G1 X108.935 Y121.579 E1.17347
G1 X108.935 Y121.202 E.01162
G1 X147.065 Y121.202 E1.17347
M73 P77 R3
G1 X147.065 Y120.824 E.01162
G1 X108.935 Y120.824 E1.17347
G1 X108.935 Y120.446 E.01162
G1 X147.065 Y120.446 E1.17347
G1 X147.065 Y120.069 E.01162
G1 X108.935 Y120.069 E1.17347
M73 P78 R3
G1 X108.935 Y119.691 E.01162
G1 X147.065 Y119.691 E1.17347
G1 X147.065 Y119.313 E.01162
G1 X108.935 Y119.313 E1.17347
G1 X108.935 Y118.936 E.01162
G1 X147.234 Y118.936 E1.1787
M106 S165.75
; CHANGE_LAYER
; Z_HEIGHT: 20.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F3000
G1 X145.234 Y118.936 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 158/176
; update layer progress
M73 L158
M991 S0 P157 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z20.6 I-.548 J-1.087 P1  F42000
G1 X108.602 Y137.398 Z20.6
G1 Z20.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z20.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X108.766 Y133.519
G1 Z20.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X123.35 Y118.935 E.63919
G1 X122.812 Y118.935 E.01667
G1 X108.935 Y132.812 E.60818
G1 X108.935 Y132.274 E.01667
G1 X122.274 Y118.935 E.5846
G1 X121.736 Y118.935 E.01667
G1 X108.935 Y131.736 E.56103
G1 X108.935 Y131.198 E.01667
G1 X121.198 Y118.935 E.53746
G1 X120.66 Y118.935 E.01667
G1 X108.935 Y130.66 E.51388
G1 X108.935 Y130.122 E.01667
G1 X120.122 Y118.935 E.49031
G1 X119.585 Y118.935 E.01667
G1 X108.935 Y129.585 E.46674
G1 X108.935 Y129.047 E.01667
G1 X119.047 Y118.935 E.44316
G1 X118.509 Y118.935 E.01667
G1 X108.935 Y128.509 E.41959
G1 X108.935 Y127.971 E.01667
G1 X117.971 Y118.935 E.39602
G1 X117.433 Y118.935 E.01667
G1 X108.935 Y127.433 E.37244
G1 X108.935 Y126.895 E.01667
G1 X116.895 Y118.935 E.34887
G1 X116.357 Y118.935 E.01667
G1 X108.935 Y126.357 E.3253
G1 X108.935 Y125.82 E.01667
G1 X115.82 Y118.935 E.30172
G1 X115.282 Y118.935 E.01667
G1 X108.935 Y125.282 E.27815
G1 X108.935 Y124.744 E.01667
G1 X114.744 Y118.935 E.25458
G1 X114.206 Y118.935 E.01667
G1 X108.935 Y124.206 E.23101
G1 X108.935 Y123.668 E.01667
G1 X113.668 Y118.935 E.20743
G1 X113.13 Y118.935 E.01667
G1 X108.935 Y123.13 E.18386
G1 X108.935 Y122.592 E.01667
G1 X112.592 Y118.935 E.16029
G1 X112.055 Y118.935 E.01667
G1 X108.935 Y122.055 E.13671
G1 X108.935 Y121.517 E.01667
G1 X111.517 Y118.935 E.11314
G1 X110.979 Y118.935 E.01667
G1 X108.935 Y120.979 E.08957
G1 X108.935 Y120.441 E.01667
G1 X110.441 Y118.935 E.06599
G1 X109.903 Y118.935 E.01667
G1 X108.935 Y119.903 E.04242
G1 X108.935 Y119.365 E.01667
G1 X109.535 Y118.766 E.02628
M204 S10000
G1 X119.03 Y125.077 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X119.03 Y126.706 E.05401
G1 X124.294 Y131.97 E.24698
G1 X124.03 Y131.97 E.00879
G1 X126.97 Y129.03 E.13796
G1 X126.97 Y126.97 E.06831
G1 X124.03 Y124.03 E.13796
G1 X124.294 Y124.03 E.00878
G1 X119.03 Y129.294 E.24698
G1 X119.03 Y130.923 E.05401
M204 S10000
G1 X140.193 Y118.766 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X127.363 Y131.596 E.56232
G1 X127.363 Y131.058 E.01667
G1 X139.485 Y118.935 E.53131
G1 X138.947 Y118.935 E.01667
G1 X127.363 Y130.52 E.50774
G1 X127.363 Y129.982 E.01667
G1 X138.409 Y118.935 E.48417
G1 X137.872 Y118.935 E.01667
G1 X127.363 Y129.444 E.46059
G1 X127.363 Y128.906 E.01667
G1 X137.334 Y118.935 E.43702
G1 X136.796 Y118.935 E.01667
G1 X127.363 Y128.369 E.41345
G1 X127.363 Y127.831 E.01667
G1 X136.258 Y118.935 E.38987
G1 X135.72 Y118.935 E.01667
G1 X127.363 Y127.293 E.3663
G1 X127.363 Y126.755 E.01667
G1 X135.182 Y118.935 E.34273
G1 X134.644 Y118.935 E.01667
G1 X127.363 Y126.217 E.31915
G1 X127.363 Y125.679 E.01667
G1 X134.107 Y118.935 E.29558
G1 X133.569 Y118.935 E.01667
G1 X127.363 Y125.142 E.27201
G1 X127.363 Y124.604 E.01667
G1 X133.031 Y118.935 E.24843
G1 X132.493 Y118.935 E.01667
G1 X127.363 Y124.066 E.22486
G1 X127.363 Y123.841 E.00698
G1 X127.206 Y123.684 E.00685
G1 X131.955 Y118.935 E.20814
G1 X131.417 Y118.935 E.01667
G1 X126.715 Y123.637 E.20609
G1 X126.177 Y123.637 E.01667
G1 X130.879 Y118.935 E.20609
G1 X130.342 Y118.935 E.01667
G1 X125.64 Y123.637 E.20609
G1 X125.102 Y123.637 E.01667
G1 X129.804 Y118.935 E.20609
G1 X129.266 Y118.935 E.01667
G1 X124.564 Y123.637 E.20609
G1 X124.026 Y123.637 E.01667
G1 X128.728 Y118.935 E.20609
G1 X128.19 Y118.935 E.01667
G1 X123.488 Y123.637 E.20609
G1 X122.95 Y123.637 E.01667
G1 X127.652 Y118.935 E.20609
G1 X127.115 Y118.935 E.01667
G1 X122.412 Y123.637 E.20609
G1 X121.875 Y123.637 E.01667
G1 X126.577 Y118.935 E.20609
G1 X126.039 Y118.935 E.01667
G1 X121.337 Y123.637 E.20609
M73 P79 R3
G1 X120.799 Y123.637 E.01667
G1 X125.501 Y118.935 E.20609
G1 X124.963 Y118.935 E.01667
G1 X120.261 Y123.637 E.20609
G1 X119.723 Y123.637 E.01667
G1 X124.425 Y118.935 E.20609
G1 X123.887 Y118.935 E.01667
G1 X119.185 Y123.637 E.20609
G1 X118.841 Y123.637 E.01068
G1 X118.637 Y123.841 E.00891
G1 X118.637 Y124.185 E.01068
G1 X108.935 Y133.887 E.42523
G1 X108.935 Y134.425 E.01667
G1 X118.637 Y124.723 E.42523
G1 X118.637 Y125.261 E.01667
G1 X108.935 Y134.963 E.42523
G1 X108.935 Y135.501 E.01667
G1 X118.637 Y125.799 E.42523
G1 X118.637 Y126.337 E.01667
G1 X108.935 Y136.039 E.42523
G1 X108.935 Y136.577 E.01667
G1 X118.637 Y126.875 E.42523
G1 X118.637 Y127.412 E.01667
G1 X108.985 Y137.065 E.42304
G1 X109.523 Y137.065 E.01667
G1 X118.637 Y127.95 E.39947
G1 X118.637 Y128.488 E.01667
G1 X110.061 Y137.065 E.3759
G1 X110.599 Y137.065 E.01667
G1 X118.637 Y129.026 E.35232
G1 X118.637 Y129.564 E.01667
G1 X111.137 Y137.065 E.32875
G1 X111.674 Y137.065 E.01667
G1 X118.637 Y130.102 E.30518
G1 X118.637 Y130.64 E.01667
G1 X112.212 Y137.065 E.2816
G1 X112.75 Y137.065 E.01667
G1 X118.637 Y131.177 E.25803
G1 X118.637 Y131.715 E.01667
G1 X113.288 Y137.065 E.23446
G1 X113.826 Y137.065 E.01667
G1 X118.684 Y132.206 E.21294
G1 X118.841 Y132.363 E.00685
G1 X119.066 Y132.363 E.00698
G1 X114.364 Y137.065 E.20609
G1 X114.902 Y137.065 E.01667
G1 X119.604 Y132.363 E.20609
G1 X120.141 Y132.363 E.01667
G1 X115.439 Y137.065 E.20609
G1 X115.977 Y137.065 E.01667
G1 X120.679 Y132.363 E.20609
G1 X121.217 Y132.363 E.01667
G1 X116.515 Y137.065 E.20609
G1 X117.053 Y137.065 E.01667
G1 X121.755 Y132.363 E.20609
G1 X122.293 Y132.363 E.01667
G1 X117.591 Y137.065 E.20609
G1 X118.129 Y137.065 E.01667
G1 X122.831 Y132.363 E.20609
G1 X123.369 Y132.363 E.01667
G1 X118.667 Y137.065 E.20609
G1 X119.204 Y137.065 E.01667
G1 X123.906 Y132.363 E.20609
G1 X124.444 Y132.363 E.01667
G1 X119.742 Y137.065 E.20609
G1 X120.28 Y137.065 E.01667
G1 X124.982 Y132.363 E.20609
G1 X125.52 Y132.363 E.01667
G1 X120.818 Y137.065 E.20609
G1 X121.356 Y137.065 E.01667
G1 X126.058 Y132.363 E.20609
G1 X126.596 Y132.363 E.01667
G1 X121.894 Y137.065 E.20609
G1 X122.431 Y137.065 E.01667
G1 X140.561 Y118.935 E.79458
G1 X141.099 Y118.935 E.01667
G1 X122.969 Y137.065 E.79458
G1 X123.507 Y137.065 E.01667
G1 X141.637 Y118.935 E.79458
G1 X142.174 Y118.935 E.01667
G1 X124.045 Y137.065 E.79458
G1 X124.583 Y137.065 E.01667
G1 X142.712 Y118.935 E.79458
G1 X143.25 Y118.935 E.01667
G1 X125.121 Y137.065 E.79458
G1 X125.659 Y137.065 E.01667
G1 X143.788 Y118.935 E.79458
G1 X144.326 Y118.935 E.01667
G1 X126.196 Y137.065 E.79458
G1 X126.734 Y137.065 E.01667
G1 X144.864 Y118.935 E.79458
G1 X145.402 Y118.935 E.01667
G1 X127.272 Y137.065 E.79458
G1 X127.81 Y137.065 E.01667
G1 X145.939 Y118.935 E.79458
G1 X146.477 Y118.935 E.01667
G1 X128.348 Y137.065 E.79458
G1 X128.886 Y137.065 E.01667
G1 X147.015 Y118.935 E.79458
G1 X147.065 Y118.935 E.00154
G1 X147.065 Y119.424 E.01513
G1 X129.424 Y137.065 E.77318
G1 X129.961 Y137.065 E.01667
G1 X147.065 Y119.961 E.74961
G1 X147.065 Y120.499 E.01667
G1 X130.499 Y137.065 E.72603
G1 X131.037 Y137.065 E.01667
G1 X147.065 Y121.037 E.70246
G1 X147.065 Y121.575 E.01667
G1 X131.575 Y137.065 E.67889
G1 X132.113 Y137.065 E.01667
G1 X147.065 Y122.113 E.65531
G1 X147.065 Y122.651 E.01667
G1 X132.651 Y137.065 E.63174
G1 X133.189 Y137.065 E.01667
G1 X147.065 Y123.189 E.60817
G1 X147.065 Y123.726 E.01667
G1 X133.726 Y137.065 E.58459
G1 X134.264 Y137.065 E.01667
G1 X147.065 Y124.264 E.56102
G1 X147.065 Y124.802 E.01667
G1 X134.802 Y137.065 E.53745
G1 X135.34 Y137.065 E.01667
G1 X147.065 Y125.34 E.51387
G1 X147.065 Y125.878 E.01667
G1 X135.878 Y137.065 E.4903
G1 X136.416 Y137.065 E.01667
G1 X147.065 Y126.416 E.46673
G1 X147.065 Y126.954 E.01667
G1 X136.954 Y137.065 E.44315
G1 X137.491 Y137.065 E.01667
G1 X147.065 Y127.491 E.41958
G1 X147.065 Y128.029 E.01667
G1 X138.029 Y137.065 E.39601
G1 X138.567 Y137.065 E.01667
G1 X147.065 Y128.567 E.37243
G1 X147.065 Y129.105 E.01667
G1 X139.105 Y137.065 E.34886
G1 X139.643 Y137.065 E.01667
G1 X147.065 Y129.643 E.32529
G1 X147.065 Y130.181 E.01667
G1 X140.181 Y137.065 E.30172
G1 X140.719 Y137.065 E.01667
G1 X147.065 Y130.719 E.27814
G1 X147.065 Y131.256 E.01667
G1 X141.256 Y137.065 E.25457
G1 X141.794 Y137.065 E.01667
G1 X147.065 Y131.794 E.231
G1 X147.065 Y132.332 E.01667
G1 X142.332 Y137.065 E.20742
G1 X142.87 Y137.065 E.01667
G1 X147.065 Y132.87 E.18385
G1 X147.065 Y133.408 E.01667
G1 X143.408 Y137.065 E.16028
G1 X143.946 Y137.065 E.01667
G1 X147.065 Y133.946 E.1367
G1 X147.065 Y134.483 E.01667
G1 X144.483 Y137.065 E.11313
G1 X145.021 Y137.065 E.01667
G1 X147.065 Y135.021 E.08956
G1 X147.065 Y135.559 E.01667
G1 X145.559 Y137.065 E.06598
G1 X146.097 Y137.065 E.01667
G1 X147.065 Y136.097 E.04241
G1 X147.065 Y136.635 E.01667
G1 X146.465 Y137.234 E.02627
; CHANGE_LAYER
; Z_HEIGHT: 20.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15000
G1 X147.065 Y136.635 E-.32216
G1 X147.065 Y136.097 E-.20438
G1 X146.63 Y136.531 E-.23346
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 159/176
; update layer progress
M73 L159
M991 S0 P158 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z20.8 I-.028 J-1.217 P1  F42000
G1 X108.602 Y137.398 Z20.8
G1 Z20.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z21 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.535 Y137.234
G1 Z20.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X108.935 Y136.635 E.02628
G1 X108.935 Y136.097 E.01667
G1 X109.903 Y137.065 E.04242
G1 X110.441 Y137.065 E.01667
G1 X108.935 Y135.559 E.06599
G1 X108.935 Y135.021 E.01667
G1 X110.979 Y137.065 E.08957
G1 X111.517 Y137.065 E.01667
G1 X108.935 Y134.483 E.11314
M73 P80 R3
G1 X108.935 Y133.945 E.01667
G1 X112.055 Y137.065 E.13671
G1 X112.592 Y137.065 E.01667
G1 X108.935 Y133.408 E.16029
G1 X108.935 Y132.87 E.01667
G1 X113.13 Y137.065 E.18386
G1 X113.668 Y137.065 E.01667
G1 X108.935 Y132.332 E.20743
G1 X108.935 Y131.794 E.01667
G1 X114.206 Y137.065 E.231
G1 X114.744 Y137.065 E.01667
G1 X108.935 Y131.256 E.25458
G1 X108.935 Y130.718 E.01667
G1 X115.282 Y137.065 E.27815
G1 X115.82 Y137.065 E.01667
G1 X108.935 Y130.18 E.30172
G1 X108.935 Y129.643 E.01667
G1 X116.357 Y137.065 E.3253
G1 X116.895 Y137.065 E.01667
G1 X108.935 Y129.105 E.34887
G1 X108.935 Y128.567 E.01667
G1 X117.433 Y137.065 E.37244
G1 X117.971 Y137.065 E.01667
G1 X108.935 Y128.029 E.39602
G1 X108.935 Y127.491 E.01667
G1 X118.509 Y137.065 E.41959
G1 X119.047 Y137.065 E.01667
G1 X108.935 Y126.953 E.44316
G1 X108.935 Y126.415 E.01667
G1 X119.585 Y137.065 E.46674
G1 X120.122 Y137.065 E.01667
G1 X108.935 Y125.878 E.49031
G1 X108.935 Y125.34 E.01667
G1 X120.66 Y137.065 E.51388
G1 X121.198 Y137.065 E.01667
G1 X108.935 Y124.802 E.53746
G1 X108.935 Y124.264 E.01667
G1 X121.906 Y137.234 E.56847
M204 S10000
G1 X118.302 Y124.349 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X118.302 Y125.978 E.05401
G1 X125.022 Y132.698 E.31529
G1 X123.302 Y132.698 E.05709
G1 X127.698 Y128.302 E.20627
G1 X127.698 Y127.698 E.02001
G1 X123.302 Y123.302 E.20627
G1 X125.022 Y123.302 E.05709
G1 X118.302 Y130.022 E.31529
G1 X118.302 Y131.651 E.05401
M204 S10000
G1 X141.806 Y137.234 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X128.091 Y123.519 E.60113
G1 X128.091 Y124.057 E.01667
G1 X141.099 Y137.065 E.57012
G1 X140.561 Y137.065 E.01667
G1 X128.091 Y124.594 E.54655
G1 X128.091 Y125.132 E.01667
G1 X140.023 Y137.065 E.52298
G1 X139.485 Y137.065 E.01667
G1 X128.091 Y125.67 E.4994
G1 X128.091 Y126.208 E.01667
G1 X138.947 Y137.065 E.47583
G1 X138.409 Y137.065 E.01667
G1 X128.091 Y126.746 E.45226
G1 X128.091 Y127.284 E.01667
G1 X137.872 Y137.065 E.42868
G1 X137.334 Y137.065 E.01667
G1 X128.091 Y127.822 E.40511
G1 X128.091 Y128.359 E.01667
G1 X136.796 Y137.065 E.38154
G1 X136.258 Y137.065 E.01667
G1 X128.091 Y128.897 E.35796
G1 X128.091 Y129.435 E.01667
G1 X135.72 Y137.065 E.33439
G1 X135.182 Y137.065 E.01667
G1 X128.091 Y129.973 E.31082
G1 X128.091 Y130.511 E.01667
G1 X134.644 Y137.065 E.28724
G1 X134.107 Y137.065 E.01667
G1 X128.091 Y131.049 E.26367
G1 X128.091 Y131.587 E.01667
G1 X133.569 Y137.065 E.2401
G1 X133.031 Y137.065 E.01667
G1 X128.091 Y132.124 E.21652
G1 X128.091 Y132.662 E.01667
G1 X132.493 Y137.065 E.19295
G1 X131.955 Y137.065 E.01667
G1 X127.934 Y133.044 E.17623
G1 X127.887 Y133.091 E.00205
G1 X127.443 Y133.091 E.01377
G1 X131.417 Y137.065 E.17418
G1 X130.879 Y137.065 E.01667
G1 X126.905 Y133.091 E.17418
G1 X126.368 Y133.091 E.01667
G1 X130.342 Y137.065 E.17418
G1 X129.804 Y137.065 E.01667
G1 X125.83 Y133.091 E.17418
G1 X125.292 Y133.091 E.01667
G1 X129.266 Y137.065 E.17418
G1 X128.728 Y137.065 E.01667
G1 X124.754 Y133.091 E.17418
G1 X124.216 Y133.091 E.01667
G1 X128.19 Y137.065 E.17418
G1 X127.652 Y137.065 E.01667
G1 X123.678 Y133.091 E.17418
G1 X123.14 Y133.091 E.01667
G1 X127.114 Y137.065 E.17418
G1 X126.577 Y137.065 E.01667
G1 X122.603 Y133.091 E.17418
G1 X122.065 Y133.091 E.01667
G1 X126.039 Y137.065 E.17418
G1 X125.501 Y137.065 E.01667
G1 X121.527 Y133.091 E.17418
G1 X120.989 Y133.091 E.01667
G1 X124.963 Y137.065 E.17418
G1 X124.425 Y137.065 E.01667
G1 X120.451 Y133.091 E.17418
G1 X119.913 Y133.091 E.01667
G1 X123.887 Y137.065 E.17418
G1 X123.35 Y137.065 E.01667
G1 X119.375 Y133.091 E.17418
G1 X118.838 Y133.091 E.01667
G1 X122.812 Y137.065 E.17418
G1 X122.274 Y137.065 E.01667
G1 X108.935 Y123.726 E.5846
G1 X108.935 Y123.188 E.01667
G1 X117.909 Y132.162 E.39332
G1 X117.909 Y131.625 E.01667
G1 X108.935 Y122.651 E.39332
G1 X108.935 Y122.113 E.01667
G1 X117.909 Y131.087 E.39332
G1 X117.909 Y130.549 E.01667
G1 X108.935 Y121.575 E.39332
G1 X108.935 Y121.037 E.01667
G1 X117.909 Y130.011 E.39332
G1 X117.909 Y129.473 E.01667
G1 X108.935 Y120.499 E.39332
G1 X108.935 Y119.961 E.01667
G1 X117.909 Y128.935 E.39332
G1 X117.909 Y128.397 E.01667
G1 X108.935 Y119.423 E.39332
G1 X108.935 Y118.935 E.01512
G1 X108.985 Y118.935 E.00154
G1 X117.909 Y127.86 E.39114
G1 X117.909 Y127.322 E.01667
G1 X109.523 Y118.935 E.36756
G1 X110.061 Y118.935 E.01667
G1 X117.909 Y126.784 E.34399
G1 X117.909 Y126.246 E.01667
G1 X110.599 Y118.935 E.32042
G1 X111.137 Y118.935 E.01667
G1 X117.909 Y125.708 E.29684
G1 X117.909 Y125.17 E.01667
G1 X111.674 Y118.935 E.27327
G1 X112.212 Y118.935 E.01667
G1 X117.909 Y124.632 E.2497
G1 X117.909 Y124.095 E.01667
G1 X112.75 Y118.935 E.22612
G1 X113.288 Y118.935 E.01667
G1 X117.909 Y123.557 E.20255
G1 X117.909 Y123.113 E.01377
G1 X117.956 Y123.066 E.00205
G1 X113.826 Y118.935 E.18103
G1 X114.364 Y118.935 E.01667
G1 X118.338 Y122.909 E.17418
G1 X118.876 Y122.909 E.01667
G1 X114.902 Y118.935 E.17418
G1 X115.439 Y118.935 E.01667
G1 X119.413 Y122.909 E.17418
G1 X119.951 Y122.909 E.01667
G1 X115.977 Y118.935 E.17418
G1 X116.515 Y118.935 E.01667
G1 X120.489 Y122.909 E.17418
G1 X121.027 Y122.909 E.01667
G1 X117.053 Y118.935 E.17418
G1 X117.591 Y118.935 E.01667
G1 X121.565 Y122.909 E.17418
G1 X122.103 Y122.909 E.01667
G1 X118.129 Y118.935 E.17418
G1 X118.666 Y118.935 E.01667
G1 X122.641 Y122.909 E.17418
G1 X123.178 Y122.909 E.01667
G1 X119.204 Y118.935 E.17418
G1 X119.742 Y118.935 E.01667
G1 X123.716 Y122.909 E.17418
G1 X124.254 Y122.909 E.01667
G1 X120.28 Y118.935 E.17418
G1 X120.818 Y118.935 E.01667
G1 X124.792 Y122.909 E.17418
G1 X125.33 Y122.909 E.01667
G1 X121.356 Y118.935 E.17418
G1 X121.894 Y118.935 E.01667
G1 X125.868 Y122.909 E.17418
G1 X126.406 Y122.909 E.01667
G1 X122.431 Y118.935 E.17418
G1 X122.969 Y118.935 E.01667
G1 X126.943 Y122.909 E.17418
G1 X127.481 Y122.909 E.01667
G1 X123.507 Y118.935 E.17418
G1 X124.045 Y118.935 E.01667
G1 X142.174 Y137.065 E.79458
G1 X142.712 Y137.065 E.01667
G1 X124.583 Y118.935 E.79458
G1 X125.121 Y118.935 E.01667
G1 X143.25 Y137.065 E.79458
G1 X143.788 Y137.065 E.01667
G1 X125.659 Y118.935 E.79458
G1 X126.196 Y118.935 E.01667
G1 X144.326 Y137.065 E.79458
G1 X144.864 Y137.065 E.01667
G1 X126.734 Y118.935 E.79458
G1 X127.272 Y118.935 E.01667
G1 X145.402 Y137.065 E.79458
G1 X145.939 Y137.065 E.01667
G1 X127.81 Y118.935 E.79458
G1 X128.348 Y118.935 E.01667
G1 X146.477 Y137.065 E.79458
G1 X147.015 Y137.065 E.01667
G1 X128.886 Y118.935 E.79458
G1 X129.424 Y118.935 E.01667
G1 X147.065 Y136.576 E.77318
G1 X147.065 Y136.039 E.01667
G1 X129.961 Y118.935 E.74961
G1 X130.499 Y118.935 E.01667
M73 P81 R3
G1 X147.065 Y135.501 E.72603
G1 X147.065 Y134.963 E.01667
G1 X131.037 Y118.935 E.70246
G1 X131.575 Y118.935 E.01667
G1 X147.065 Y134.425 E.67889
G1 X147.065 Y133.887 E.01667
G1 X132.113 Y118.935 E.65531
G1 X132.651 Y118.935 E.01667
G1 X147.065 Y133.349 E.63174
G1 X147.065 Y132.811 E.01667
G1 X133.189 Y118.935 E.60817
G1 X133.726 Y118.935 E.01667
G1 X147.065 Y132.274 E.58459
G1 X147.065 Y131.736 E.01667
G1 X134.264 Y118.935 E.56102
G1 X134.802 Y118.935 E.01667
G1 X147.065 Y131.198 E.53745
G1 X147.065 Y130.66 E.01667
G1 X135.34 Y118.935 E.51387
G1 X135.878 Y118.935 E.01667
G1 X147.065 Y130.122 E.4903
G1 X147.065 Y129.584 E.01667
G1 X136.416 Y118.935 E.46673
G1 X136.954 Y118.935 E.01667
G1 X147.065 Y129.047 E.44315
G1 X147.065 Y128.509 E.01667
G1 X137.491 Y118.935 E.41958
G1 X138.029 Y118.935 E.01667
G1 X147.065 Y127.971 E.39601
G1 X147.065 Y127.433 E.01667
G1 X138.567 Y118.935 E.37244
G1 X139.105 Y118.935 E.01667
G1 X147.065 Y126.895 E.34886
G1 X147.065 Y126.357 E.01667
G1 X139.643 Y118.935 E.32529
G1 X140.181 Y118.935 E.01667
G1 X147.065 Y125.819 E.30172
G1 X147.065 Y125.282 E.01667
G1 X140.718 Y118.935 E.27814
G1 X141.256 Y118.935 E.01667
G1 X147.065 Y124.744 E.25457
G1 X147.065 Y124.206 E.01667
G1 X141.794 Y118.935 E.231
G1 X142.332 Y118.935 E.01667
G1 X147.065 Y123.668 E.20742
G1 X147.065 Y123.13 E.01667
G1 X142.87 Y118.935 E.18385
G1 X143.408 Y118.935 E.01667
G1 X147.065 Y122.592 E.16028
G1 X147.065 Y122.054 E.01667
G1 X143.946 Y118.935 E.1367
G1 X144.483 Y118.935 E.01667
G1 X147.065 Y121.517 E.11313
G1 X147.065 Y120.979 E.01667
G1 X145.021 Y118.935 E.08956
G1 X145.559 Y118.935 E.01667
G1 X147.065 Y120.441 E.06598
G1 X147.065 Y119.903 E.01667
G1 X146.097 Y118.935 E.04241
G1 X146.635 Y118.935 E.01667
G1 X147.234 Y119.535 E.02627
; CHANGE_LAYER
; Z_HEIGHT: 20.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15000
G1 X146.635 Y118.935 E-.32216
G1 X146.097 Y118.935 E-.20438
G1 X146.531 Y119.37 E-.23346
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 160/176
; update layer progress
M73 L160
M991 S0 P159 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z21 I-.522 J-1.099 P1  F42000
G1 X108.602 Y137.398 Z21
G1 Z20.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F5340
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5340
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z21.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z20.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5340
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 21
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 161/176
; update layer progress
M73 L161
M991 S0 P160 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z21.2 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z21.2
G1 Z21
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5300
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
M73 P82 R3
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5300
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z21.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.65 Y137.05
G1 Z21
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5300
M204 S6000
G1 X114.022 Y137.05 E.05401
G1 X108.95 Y131.978 E.23791
G1 X108.95 Y131.698 E.0093
G1 X121.698 Y118.95 E.59801
G1 X118.95 Y118.95 E.09114
G1 X137.05 Y137.05 E.84908
G1 X134.302 Y137.05 E.09114
G1 X147.05 Y124.302 E.59801
G1 X147.05 Y124.022 E.0093
G1 X141.978 Y118.95 E.23791
G1 X144.726 Y118.95 E.09114
G1 X126.626 Y137.05 E.84908
G1 X129.374 Y137.05 E.09114
G1 X111.274 Y118.95 E.84908
G1 X114.022 Y118.95 E.09114
G1 X108.95 Y124.022 E.23791
G1 X108.95 Y124.302 E.0093
G1 X121.698 Y137.05 E.59801
G1 X118.95 Y137.05 E.09114
G1 X137.05 Y118.95 E.84908
G1 X134.302 Y118.95 E.09114
G1 X147.05 Y131.698 E.59801
G1 X147.05 Y131.978 E.0093
G1 X141.978 Y137.05 E.23791
G1 X144.726 Y137.05 E.09114
G1 X126.626 Y118.95 E.84908
G1 X129.374 Y118.95 E.09114
G1 X111.274 Y137.05 E.84908
G1 X109.646 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 21.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X111.274 Y137.05 E-.61876
G1 X111.537 Y136.787 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 162/176
; update layer progress
M73 L162
M991 S0 P161 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z21.4 I-.248 J-1.191 P1  F42000
G1 X108.602 Y137.398 Z21.4
G1 Z21.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5290
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5290
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z21.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z21.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5290
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
M73 P83 R3
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 21.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 163/176
; update layer progress
M73 L163
M991 S0 P162 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z21.6 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z21.6
G1 Z21.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5300
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5300
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M73 P83 R2
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z21.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.65 Y137.05
G1 Z21.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5300
M204 S6000
G1 X114.022 Y137.05 E.05401
G1 X108.95 Y131.978 E.23791
G1 X108.95 Y131.698 E.0093
G1 X121.698 Y118.95 E.59801
G1 X118.95 Y118.95 E.09114
G1 X137.05 Y137.05 E.84908
G1 X134.302 Y137.05 E.09114
G1 X147.05 Y124.302 E.59801
G1 X147.05 Y124.022 E.0093
G1 X141.978 Y118.95 E.23791
G1 X144.726 Y118.95 E.09114
G1 X126.626 Y137.05 E.84908
G1 X129.374 Y137.05 E.09114
G1 X111.274 Y118.95 E.84908
G1 X114.022 Y118.95 E.09114
G1 X108.95 Y124.022 E.23791
G1 X108.95 Y124.302 E.0093
G1 X121.698 Y137.05 E.59801
G1 X118.95 Y137.05 E.09114
G1 X137.05 Y118.95 E.84908
G1 X134.302 Y118.95 E.09114
G1 X147.05 Y131.698 E.59801
G1 X147.05 Y131.978 E.0093
G1 X141.978 Y137.05 E.23791
G1 X144.726 Y137.05 E.09114
G1 X126.626 Y118.95 E.84908
G1 X129.374 Y118.95 E.09114
G1 X111.274 Y137.05 E.84908
G1 X109.646 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 21.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X111.274 Y137.05 E-.61876
G1 X111.537 Y136.787 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 164/176
; update layer progress
M73 L164
M991 S0 P163 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z21.8 I-.248 J-1.191 P1  F42000
G1 X108.602 Y137.398 Z21.8
G1 Z21.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5290
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5290
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M73 P84 R2
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z22 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z21.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5290
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 21.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 165/176
; update layer progress
M73 L165
M991 S0 P164 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z22 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z22
G1 Z21.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5300
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5300
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z22.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.65 Y137.05
G1 Z21.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5300
M204 S6000
G1 X114.022 Y137.05 E.05401
G1 X108.95 Y131.978 E.23791
G1 X108.95 Y131.698 E.0093
G1 X121.698 Y118.95 E.59801
G1 X118.95 Y118.95 E.09114
G1 X137.05 Y137.05 E.84908
G1 X134.302 Y137.05 E.09114
G1 X147.05 Y124.302 E.59801
G1 X147.05 Y124.022 E.0093
G1 X141.978 Y118.95 E.23791
G1 X144.726 Y118.95 E.09114
G1 X126.626 Y137.05 E.84908
G1 X129.374 Y137.05 E.09114
G1 X111.274 Y118.95 E.84908
G1 X114.022 Y118.95 E.09114
G1 X108.95 Y124.022 E.23791
G1 X108.95 Y124.302 E.0093
G1 X121.698 Y137.05 E.59801
G1 X118.95 Y137.05 E.09114
G1 X137.05 Y118.95 E.84908
G1 X134.302 Y118.95 E.09114
G1 X147.05 Y131.698 E.59801
G1 X147.05 Y131.978 E.0093
G1 X141.978 Y137.05 E.23791
G1 X144.726 Y137.05 E.09114
G1 X126.626 Y118.95 E.84908
M73 P85 R2
G1 X129.374 Y118.95 E.09114
G1 X111.274 Y137.05 E.84908
G1 X109.646 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 22
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X111.274 Y137.05 E-.61876
G1 X111.537 Y136.787 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 166/176
; update layer progress
M73 L166
M991 S0 P165 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z22.2 I-.248 J-1.191 P1  F42000
G1 X108.602 Y137.398 Z22.2
G1 Z22
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5290
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5290
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z22.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z22
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5290
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 22.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 167/176
; update layer progress
M73 L167
M991 S0 P166 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z22.4 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z22.4
G1 Z22.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5300
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5300
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z22.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.65 Y137.05
G1 Z22.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5300
M204 S6000
G1 X114.022 Y137.05 E.05401
G1 X108.95 Y131.978 E.23791
G1 X108.95 Y131.698 E.0093
G1 X121.698 Y118.95 E.59801
M73 P86 R2
G1 X118.95 Y118.95 E.09114
G1 X137.05 Y137.05 E.84908
G1 X134.302 Y137.05 E.09114
G1 X147.05 Y124.302 E.59801
G1 X147.05 Y124.022 E.0093
G1 X141.978 Y118.95 E.23791
G1 X144.726 Y118.95 E.09114
G1 X126.626 Y137.05 E.84908
G1 X129.374 Y137.05 E.09114
G1 X111.274 Y118.95 E.84908
G1 X114.022 Y118.95 E.09114
G1 X108.95 Y124.022 E.23791
G1 X108.95 Y124.302 E.0093
G1 X121.698 Y137.05 E.59801
G1 X118.95 Y137.05 E.09114
G1 X137.05 Y118.95 E.84908
G1 X134.302 Y118.95 E.09114
G1 X147.05 Y131.698 E.59801
G1 X147.05 Y131.978 E.0093
G1 X141.978 Y137.05 E.23791
G1 X144.726 Y137.05 E.09114
G1 X126.626 Y118.95 E.84908
G1 X129.374 Y118.95 E.09114
G1 X111.274 Y137.05 E.84908
G1 X109.646 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 22.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X111.274 Y137.05 E-.61876
G1 X111.537 Y136.787 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 168/176
; update layer progress
M73 L168
M991 S0 P167 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z22.6 I-.248 J-1.191 P1  F42000
G1 X108.602 Y137.398 Z22.6
G1 Z22.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5290
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5290
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z22.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z22.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5290
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 22.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 169/176
; update layer progress
M73 L169
M991 S0 P168 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z22.8 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z22.8
G1 Z22.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5300
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
M73 P87 R2
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5300
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z23 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.65 Y137.05
G1 Z22.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5300
M204 S6000
G1 X114.022 Y137.05 E.05401
G1 X108.95 Y131.978 E.23791
G1 X108.95 Y131.698 E.0093
G1 X121.698 Y118.95 E.59801
G1 X118.95 Y118.95 E.09114
G1 X137.05 Y137.05 E.84908
G1 X134.302 Y137.05 E.09114
G1 X147.05 Y124.302 E.59801
G1 X147.05 Y124.022 E.0093
G1 X141.978 Y118.95 E.23791
G1 X144.726 Y118.95 E.09114
G1 X126.626 Y137.05 E.84908
G1 X129.374 Y137.05 E.09114
G1 X111.274 Y118.95 E.84908
G1 X114.022 Y118.95 E.09114
G1 X108.95 Y124.022 E.23791
G1 X108.95 Y124.302 E.0093
G1 X121.698 Y137.05 E.59801
G1 X118.95 Y137.05 E.09114
G1 X137.05 Y118.95 E.84908
G1 X134.302 Y118.95 E.09114
G1 X147.05 Y131.698 E.59801
G1 X147.05 Y131.978 E.0093
G1 X141.978 Y137.05 E.23791
G1 X144.726 Y137.05 E.09114
G1 X126.626 Y118.95 E.84908
G1 X129.374 Y118.95 E.09114
G1 X111.274 Y137.05 E.84908
G1 X109.646 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 22.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15476.087
G1 X111.274 Y137.05 E-.61876
G1 X111.537 Y136.787 E-.14125
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 170/176
; update layer progress
M73 L170
M991 S0 P169 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z23 I-.248 J-1.191 P1  F42000
G1 X108.602 Y137.398 Z23
G1 Z22.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F5290
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F5290
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z23.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.646 Y137.05
G1 Z22.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F5290
M204 S6000
G1 X111.274 Y137.05 E.05401
G1 X129.374 Y118.95 E.84908
G1 X126.626 Y118.95 E.09114
G1 X144.726 Y137.05 E.84908
G1 X141.978 Y137.05 E.09114
G1 X147.05 Y131.978 E.23791
G1 X147.05 Y131.698 E.0093
G1 X134.302 Y118.95 E.59801
G1 X137.05 Y118.95 E.09114
G1 X118.95 Y137.05 E.84908
G1 X121.698 Y137.05 E.09114
G1 X108.95 Y124.302 E.59801
M73 P88 R2
G1 X108.95 Y124.022 E.0093
G1 X114.022 Y118.95 E.23791
G1 X111.274 Y118.95 E.09114
G1 X129.374 Y137.05 E.84908
G1 X126.626 Y137.05 E.09114
G1 X144.726 Y118.95 E.84908
G1 X141.978 Y118.95 E.09114
G1 X147.05 Y124.022 E.23791
G1 X147.05 Y124.302 E.0093
G1 X134.302 Y137.05 E.59801
G1 X137.05 Y137.05 E.09114
G1 X118.95 Y118.95 E.84908
G1 X121.698 Y118.95 E.09114
G1 X108.95 Y131.698 E.59801
G1 X108.95 Y131.978 E.0093
G1 X114.022 Y137.05 E.23791
G1 X115.65 Y137.05 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 23
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15476.087
G1 X114.022 Y137.05 E-.61876
G1 X113.759 Y136.787 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 171/176
; update layer progress
M73 L171
M991 S0 P170 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z23.2 I-.143 J-1.209 P1  F42000
G1 X108.602 Y137.398 Z23.2
G1 Z23
G1 E.8 F1800
; FEATURE: Inner wall
G1 F6314
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F6314
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
G1 F12000
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z23.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X115.273 Y136.673
G1 Z23
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F6314
M204 S6000
G1 X113.645 Y136.673 E.05401
G1 X109.327 Y132.355 E.20253
G1 X109.327 Y131.321 E.03433
G1 X121.321 Y119.328 E.56262
G1 X119.328 Y119.328 E.06611
G1 X136.673 Y136.673 E.81369
G1 X134.679 Y136.673 E.06612
G1 X146.673 Y124.679 E.56262
G1 X146.673 Y123.645 E.03432
G1 X142.355 Y119.328 E.20253
G1 X144.348 Y119.328 E.06611
G1 X127.003 Y136.673 E.81369
G1 X128.997 Y136.673 E.06612
G1 X111.652 Y119.328 E.81369
G1 X113.645 Y119.328 E.06611
G1 X109.327 Y123.645 E.20253
G1 X109.327 Y124.679 E.03433
G1 X121.321 Y136.673 E.56262
G1 X119.327 Y136.673 E.06612
G1 X136.672 Y119.328 E.81369
G1 X134.679 Y119.328 E.06611
G1 X146.673 Y131.321 E.56262
G1 X146.673 Y132.355 E.03432
G1 X142.355 Y136.673 E.20253
G1 X144.348 Y136.673 E.06612
G1 X127.003 Y119.328 E.81369
G1 X128.997 Y119.328 E.06611
G1 X111.652 Y136.673 E.81369
G1 X110.023 Y136.673 E.05401
M204 S10000
G1 X146.876 Y118.965 F42000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38307
G1 F6314
M204 S6000
G1 X109.124 Y118.965 E1.04641
G1 X108.992 Y118.992 E.00373
G1 X108.965 Y119.124 E.00373
G1 X108.965 Y136.876 E.49205
G1 X108.992 Y137.008 E.00373
G1 X109.124 Y137.035 E.00373
G1 X146.876 Y137.035 E1.04641
G1 X147.008 Y137.008 E.00373
G1 X147.035 Y136.876 E.00373
G1 X147.035 Y119.124 E.49205
G1 X147.008 Y118.992 E.00373
G1 X146.935 Y118.977 E.00207
M106 S255
; CHANGE_LAYER
; Z_HEIGHT: 23.2
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F12000
G1 X147.008 Y118.992 E-.02837
G1 X147.035 Y119.124 E-.05117
G1 X147.035 Y120.915 E-.68045
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 172/176
; update layer progress
M73 L172
M991 S0 P171 ;notify layer change
M106 S255
; OBJECT_ID: 15
M204 S10000
G17
G3 Z23.4 I-.48 J-1.118 P1  F42000
G1 X108.602 Y137.398 Z23.4
G1 Z23.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
M73 P88 R1
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
M73 P89 R1
G3 Z23.6 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.686 Y118.769
G1 Z23.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40296
; LAYER_HEIGHT: 0.4
G1 F3000
M204 S6000
G1 X108.972 Y119.484 E.05249
G1 X108.972 Y120.124 E.03329
G1 X110.124 Y118.972 E.08468
G1 X110.765 Y118.972 E.03328
G1 X108.972 Y120.765 E.13176
G1 X108.972 Y121.405 E.03328
G1 X111.405 Y118.972 E.17883
G1 X112.046 Y118.972 E.03328
G1 X108.972 Y122.046 E.2259
G1 X108.972 Y122.687 E.03328
G1 X112.687 Y118.972 E.27297
G1 X113.327 Y118.972 E.03328
G1 X108.972 Y123.327 E.32004
G1 X108.972 Y123.968 E.03328
G1 X113.968 Y118.972 E.36712
G1 X114.608 Y118.972 E.03328
G1 X108.972 Y124.608 E.41419
G1 X108.972 Y125.249 E.03328
G1 X115.249 Y118.972 E.46126
G1 X115.889 Y118.972 E.03329
G1 X108.972 Y125.889 E.50833
G1 X108.972 Y126.53 E.03329
G1 X116.53 Y118.972 E.5554
G1 X117.171 Y118.972 E.03328
G1 X108.972 Y127.171 E.60248
G1 X108.972 Y127.811 E.03328
G1 X117.811 Y118.972 E.64955
G1 X118.452 Y118.972 E.03329
G1 X108.972 Y128.452 E.69662
G1 X108.972 Y129.092 E.03328
G1 X119.092 Y118.972 E.74369
G1 X119.733 Y118.972 E.03328
G1 X108.972 Y129.733 E.79076
G1 X108.972 Y130.374 E.03329
G1 X120.374 Y118.972 E.83784
G1 X121.014 Y118.972 E.03328
G1 X108.972 Y131.014 E.88491
G1 X108.972 Y131.655 E.03328
G1 X121.655 Y118.972 E.93198
G1 X122.295 Y118.972 E.03328
G1 X108.972 Y132.295 E.97905
G1 X108.972 Y132.936 E.03329
G1 X122.936 Y118.972 E1.02613
G1 X123.576 Y118.972 E.03329
G1 X108.972 Y133.576 E1.0732
G1 X108.972 Y134.217 E.03328
G1 X124.217 Y118.972 E1.12027
G1 X124.858 Y118.972 E.03328
G1 X108.972 Y134.858 E1.16734
G1 X108.972 Y135.498 E.03328
G1 X125.498 Y118.972 E1.21441
G1 X126.139 Y118.972 E.03328
G1 X108.972 Y136.139 E1.26149
G1 X108.972 Y136.779 E.03328
G1 X126.779 Y118.972 E1.30856
G1 X127.42 Y118.972 E.03328
G1 X109.364 Y137.028 E1.32685
G1 X110.004 Y137.028 E.03329
G1 X128.061 Y118.972 E1.32685
G1 X128.701 Y118.972 E.03328
G1 X110.645 Y137.028 E1.32685
G1 X111.285 Y137.028 E.03328
G1 X129.342 Y118.972 E1.32685
G1 X129.982 Y118.972 E.03328
G1 X111.926 Y137.028 E1.32685
G1 X112.566 Y137.028 E.03329
G1 X130.623 Y118.972 E1.32685
M73 P90 R1
G1 X131.263 Y118.972 E.03328
G1 X113.207 Y137.028 E1.32685
G1 X113.848 Y137.028 E.03328
G1 X131.904 Y118.972 E1.32685
G1 X132.545 Y118.972 E.03329
G1 X114.488 Y137.028 E1.32685
G1 X115.129 Y137.028 E.03328
G1 X133.185 Y118.972 E1.32685
G1 X133.826 Y118.972 E.03328
G1 X115.769 Y137.028 E1.32685
G1 X116.41 Y137.028 E.03328
G1 X134.466 Y118.972 E1.32685
G1 X135.107 Y118.972 E.03329
G1 X117.051 Y137.028 E1.32685
G1 X117.691 Y137.028 E.03328
G1 X135.747 Y118.972 E1.32685
G1 X136.388 Y118.972 E.03328
G1 X118.332 Y137.028 E1.32685
G1 X118.972 Y137.028 E.03328
G1 X137.029 Y118.972 E1.32685
G1 X137.669 Y118.972 E.03328
G1 X119.613 Y137.028 E1.32685
G1 X120.253 Y137.028 E.03328
G1 X138.31 Y118.972 E1.32685
G1 X138.95 Y118.972 E.03328
G1 X120.894 Y137.028 E1.32684
G1 X121.535 Y137.028 E.03328
G1 X139.591 Y118.972 E1.32684
G1 X140.232 Y118.972 E.03329
G1 X122.175 Y137.028 E1.32685
G1 X122.816 Y137.028 E.03328
G1 X140.872 Y118.972 E1.32685
G1 X141.513 Y118.972 E.03328
G1 X123.456 Y137.028 E1.32685
G1 X124.097 Y137.028 E.03328
G1 X142.153 Y118.972 E1.32685
G1 X142.794 Y118.972 E.03328
G1 X124.737 Y137.028 E1.32685
G1 X125.378 Y137.028 E.03328
G1 X143.434 Y118.972 E1.32685
M73 P91 R1
G1 X144.075 Y118.972 E.03328
G1 X126.019 Y137.028 E1.32685
G1 X126.659 Y137.028 E.03329
G1 X144.716 Y118.972 E1.32685
G1 X145.356 Y118.972 E.03328
G1 X127.3 Y137.028 E1.32685
G1 X127.94 Y137.028 E.03328
G1 X145.997 Y118.972 E1.32685
G1 X146.637 Y118.972 E.03328
G1 X128.581 Y137.028 E1.32685
G1 X129.222 Y137.028 E.03329
G1 X147.028 Y119.222 E1.30849
G1 X147.028 Y119.862 E.03329
G1 X129.862 Y137.028 E1.26142
G1 X130.503 Y137.028 E.03328
G1 X147.028 Y120.503 E1.21435
G1 X147.028 Y121.143 E.03328
G1 X131.143 Y137.028 E1.16728
G1 X131.784 Y137.028 E.03328
G1 X147.028 Y121.784 E1.1202
G1 X147.028 Y122.424 E.03328
G1 X132.424 Y137.028 E1.07313
G1 X133.065 Y137.028 E.03328
G1 X147.028 Y123.065 E1.02606
G1 X147.028 Y123.706 E.03328
G1 X133.706 Y137.028 E.97899
G1 X134.346 Y137.028 E.03328
G1 X147.028 Y124.346 E.93192
G1 X147.028 Y124.987 E.03328
G1 X134.987 Y137.028 E.88484
G1 X135.627 Y137.028 E.03329
G1 X147.028 Y125.627 E.83777
G1 X147.028 Y126.268 E.03328
G1 X136.268 Y137.028 E.7907
G1 X136.909 Y137.028 E.03328
G1 X147.028 Y126.909 E.74363
G1 X147.028 Y127.549 E.03328
G1 X137.549 Y137.028 E.69656
G1 X138.19 Y137.028 E.03328
G1 X147.028 Y128.19 E.64948
G1 X147.028 Y128.83 E.03328
G1 X138.83 Y137.028 E.60241
G1 X139.471 Y137.028 E.03328
G1 X147.028 Y129.471 E.55534
G1 X147.028 Y130.111 E.03328
G1 X140.111 Y137.028 E.50827
G1 X140.752 Y137.028 E.03328
G1 X147.028 Y130.752 E.46119
G1 X147.028 Y131.393 E.03328
G1 X141.393 Y137.028 E.41412
G1 X142.033 Y137.028 E.03328
G1 X147.028 Y132.033 E.36705
G1 X147.028 Y132.674 E.03329
G1 X142.674 Y137.028 E.31998
G1 X143.314 Y137.028 E.03329
G1 X147.028 Y133.314 E.27291
G1 X147.028 Y133.955 E.03328
G1 X143.955 Y137.028 E.22583
M73 P92 R1
G1 X144.596 Y137.028 E.03328
G1 X147.028 Y134.596 E.17876
G1 X147.028 Y135.236 E.03328
G1 X145.236 Y137.028 E.13169
G1 X145.877 Y137.028 E.03328
G1 X147.028 Y135.877 E.08462
G1 X147.028 Y136.517 E.03328
G1 X146.315 Y137.231 E.05243
M106 S183.6
; CHANGE_LAYER
; Z_HEIGHT: 23.4
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F3000
G1 X147.028 Y136.517 E-.3834
G1 X147.028 Y135.877 E-.24342
G1 X146.78 Y136.125 E-.13318
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 173/176
; update layer progress
M73 L173
M991 S0 P172 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z23.6 I-.041 J-1.216 P1  F42000
G1 X108.602 Y137.398 Z23.6
G1 Z23.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z23.8 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.535 Y137.234
G1 Z23.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X108.935 Y136.635 E.02628
G1 X108.935 Y136.097 E.01667
G1 X109.903 Y137.065 E.04242
G1 X110.441 Y137.065 E.01667
G1 X108.935 Y135.559 E.06599
G1 X108.935 Y135.021 E.01667
G1 X110.979 Y137.065 E.08957
G1 X111.517 Y137.065 E.01667
G1 X108.935 Y134.483 E.11314
G1 X108.935 Y133.945 E.01667
G1 X112.055 Y137.065 E.13671
G1 X112.592 Y137.065 E.01667
G1 X108.935 Y133.408 E.16029
G1 X108.935 Y132.87 E.01667
G1 X113.13 Y137.065 E.18386
G1 X113.668 Y137.065 E.01667
G1 X108.935 Y132.332 E.20743
G1 X108.935 Y131.794 E.01667
G1 X114.206 Y137.065 E.231
G1 X114.744 Y137.065 E.01667
G1 X108.935 Y131.256 E.25458
G1 X108.935 Y130.718 E.01667
G1 X115.282 Y137.065 E.27815
G1 X115.82 Y137.065 E.01667
G1 X108.935 Y130.18 E.30172
G1 X108.935 Y129.643 E.01667
G1 X116.357 Y137.065 E.3253
G1 X116.895 Y137.065 E.01667
G1 X108.935 Y129.105 E.34887
G1 X108.935 Y128.567 E.01667
G1 X117.433 Y137.065 E.37244
G1 X117.971 Y137.065 E.01667
G1 X108.935 Y128.029 E.39602
G1 X108.935 Y127.491 E.01667
G1 X118.509 Y137.065 E.41959
G1 X119.047 Y137.065 E.01667
G1 X108.935 Y126.953 E.44316
G1 X108.935 Y126.415 E.01667
G1 X119.585 Y137.065 E.46674
G1 X120.122 Y137.065 E.01667
G1 X108.935 Y125.878 E.49031
G1 X108.935 Y125.34 E.01667
G1 X120.66 Y137.065 E.51388
G1 X121.198 Y137.065 E.01667
G1 X108.935 Y124.802 E.53746
G1 X108.935 Y124.264 E.01667
G1 X121.736 Y137.065 E.56103
G1 X122.274 Y137.065 E.01667
G1 X108.935 Y123.726 E.5846
G1 X108.935 Y123.188 E.01667
G1 X122.812 Y137.065 E.60818
G1 X123.35 Y137.065 E.01667
G1 X108.935 Y122.651 E.63175
G1 X108.935 Y122.113 E.01667
G1 X123.887 Y137.065 E.65532
G1 X124.425 Y137.065 E.01667
G1 X108.935 Y121.575 E.6789
G1 X108.935 Y121.037 E.01667
G1 X124.963 Y137.065 E.70247
G1 X125.501 Y137.065 E.01667
G1 X108.935 Y120.499 E.72604
G1 X108.935 Y119.961 E.01667
G1 X126.039 Y137.065 E.74961
G1 X126.577 Y137.065 E.01667
G1 X108.935 Y119.423 E.77319
G1 X108.935 Y118.935 E.01512
G1 X108.985 Y118.935 E.00154
G1 X127.114 Y137.065 E.79458
G1 X127.652 Y137.065 E.01667
G1 X109.523 Y118.935 E.79458
G1 X110.061 Y118.935 E.01667
G1 X128.19 Y137.065 E.79458
G1 X128.728 Y137.065 E.01667
G1 X110.599 Y118.935 E.79458
G1 X111.137 Y118.935 E.01667
G1 X129.266 Y137.065 E.79458
G1 X129.804 Y137.065 E.01667
G1 X111.674 Y118.935 E.79458
G1 X112.212 Y118.935 E.01667
G1 X130.342 Y137.065 E.79458
G1 X130.879 Y137.065 E.01667
G1 X112.75 Y118.935 E.79458
G1 X113.288 Y118.935 E.01667
G1 X131.417 Y137.065 E.79458
G1 X131.955 Y137.065 E.01667
G1 X113.826 Y118.935 E.79458
G1 X114.364 Y118.935 E.01667
G1 X132.493 Y137.065 E.79458
G1 X133.031 Y137.065 E.01667
G1 X114.902 Y118.935 E.79458
G1 X115.439 Y118.935 E.01667
G1 X133.569 Y137.065 E.79458
G1 X134.107 Y137.065 E.01667
G1 X115.977 Y118.935 E.79458
G1 X116.515 Y118.935 E.01667
G1 X134.644 Y137.065 E.79458
G1 X135.182 Y137.065 E.01667
G1 X117.053 Y118.935 E.79458
G1 X117.591 Y118.935 E.01667
G1 X135.72 Y137.065 E.79458
G1 X136.258 Y137.065 E.01667
G1 X118.129 Y118.935 E.79458
G1 X118.666 Y118.935 E.01667
G1 X136.796 Y137.065 E.79458
G1 X137.334 Y137.065 E.01667
G1 X119.204 Y118.935 E.79458
G1 X119.742 Y118.935 E.01667
G1 X137.872 Y137.065 E.79458
G1 X138.409 Y137.065 E.01667
G1 X120.28 Y118.935 E.79458
G1 X120.818 Y118.935 E.01667
G1 X138.947 Y137.065 E.79458
G1 X139.485 Y137.065 E.01667
G1 X121.356 Y118.935 E.79458
G1 X121.894 Y118.935 E.01667
G1 X140.023 Y137.065 E.79458
G1 X140.561 Y137.065 E.01667
G1 X122.431 Y118.935 E.79458
G1 X122.969 Y118.935 E.01667
G1 X141.099 Y137.065 E.79458
G1 X141.637 Y137.065 E.01667
G1 X123.507 Y118.935 E.79458
G1 X124.045 Y118.935 E.01667
G1 X142.174 Y137.065 E.79458
G1 X142.712 Y137.065 E.01667
G1 X124.583 Y118.935 E.79458
G1 X125.121 Y118.935 E.01667
G1 X143.25 Y137.065 E.79458
G1 X143.788 Y137.065 E.01667
G1 X125.659 Y118.935 E.79458
G1 X126.196 Y118.935 E.01667
G1 X144.326 Y137.065 E.79458
G1 X144.864 Y137.065 E.01667
G1 X126.734 Y118.935 E.79458
M73 P93 R1
G1 X127.272 Y118.935 E.01667
G1 X145.402 Y137.065 E.79458
G1 X145.939 Y137.065 E.01667
G1 X127.81 Y118.935 E.79458
G1 X128.348 Y118.935 E.01667
G1 X146.477 Y137.065 E.79458
G1 X147.015 Y137.065 E.01667
G1 X128.886 Y118.935 E.79458
G1 X129.424 Y118.935 E.01667
G1 X147.065 Y136.576 E.77318
G1 X147.065 Y136.039 E.01667
G1 X129.961 Y118.935 E.74961
G1 X130.499 Y118.935 E.01667
G1 X147.065 Y135.501 E.72603
G1 X147.065 Y134.963 E.01667
G1 X131.037 Y118.935 E.70246
G1 X131.575 Y118.935 E.01667
G1 X147.065 Y134.425 E.67889
G1 X147.065 Y133.887 E.01667
G1 X132.113 Y118.935 E.65531
G1 X132.651 Y118.935 E.01667
G1 X147.065 Y133.349 E.63174
G1 X147.065 Y132.811 E.01667
G1 X133.189 Y118.935 E.60817
G1 X133.726 Y118.935 E.01667
G1 X147.065 Y132.274 E.58459
G1 X147.065 Y131.736 E.01667
G1 X134.264 Y118.935 E.56102
G1 X134.802 Y118.935 E.01667
G1 X147.065 Y131.198 E.53745
G1 X147.065 Y130.66 E.01667
G1 X135.34 Y118.935 E.51387
G1 X135.878 Y118.935 E.01667
G1 X147.065 Y130.122 E.4903
G1 X147.065 Y129.584 E.01667
G1 X136.416 Y118.935 E.46673
G1 X136.954 Y118.935 E.01667
G1 X147.065 Y129.047 E.44315
G1 X147.065 Y128.509 E.01667
G1 X137.491 Y118.935 E.41958
G1 X138.029 Y118.935 E.01667
G1 X147.065 Y127.971 E.39601
G1 X147.065 Y127.433 E.01667
G1 X138.567 Y118.935 E.37244
G1 X139.105 Y118.935 E.01667
G1 X147.065 Y126.895 E.34886
G1 X147.065 Y126.357 E.01667
G1 X139.643 Y118.935 E.32529
G1 X140.181 Y118.935 E.01667
G1 X147.065 Y125.819 E.30172
G1 X147.065 Y125.282 E.01667
G1 X140.718 Y118.935 E.27814
G1 X141.256 Y118.935 E.01667
G1 X147.065 Y124.744 E.25457
G1 X147.065 Y124.206 E.01667
G1 X141.794 Y118.935 E.231
G1 X142.332 Y118.935 E.01667
G1 X147.065 Y123.668 E.20742
G1 X147.065 Y123.13 E.01667
G1 X142.87 Y118.935 E.18385
G1 X143.408 Y118.935 E.01667
G1 X147.065 Y122.592 E.16028
G1 X147.065 Y122.054 E.01667
G1 X143.946 Y118.935 E.1367
G1 X144.483 Y118.935 E.01667
G1 X147.065 Y121.517 E.11313
G1 X147.065 Y120.979 E.01667
G1 X145.021 Y118.935 E.08956
G1 X145.559 Y118.935 E.01667
G1 X147.065 Y120.441 E.06598
G1 X147.065 Y119.903 E.01667
G1 X146.097 Y118.935 E.04241
G1 X146.635 Y118.935 E.01667
G1 X147.234 Y119.535 E.02627
; CHANGE_LAYER
; Z_HEIGHT: 23.6
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15000
G1 X146.635 Y118.935 E-.32216
G1 X146.097 Y118.935 E-.20438
G1 X146.531 Y119.37 E-.23346
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 174/176
; update layer progress
M73 L174
M991 S0 P173 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z23.8 I-.522 J-1.099 P1  F42000
G1 X108.602 Y137.398 Z23.8
G1 Z23.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z24 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X108.766 Y119.535
G1 Z23.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X109.365 Y118.935 E.02628
G1 X109.903 Y118.935 E.01667
G1 X108.935 Y119.903 E.04242
G1 X108.935 Y120.441 E.01667
G1 X110.441 Y118.935 E.06599
G1 X110.979 Y118.935 E.01667
G1 X108.935 Y120.979 E.08957
G1 X108.935 Y121.517 E.01667
G1 X111.517 Y118.935 E.11314
G1 X112.055 Y118.935 E.01667
G1 X108.935 Y122.055 E.13671
G1 X108.935 Y122.592 E.01667
G1 X112.592 Y118.935 E.16029
G1 X113.13 Y118.935 E.01667
G1 X108.935 Y123.13 E.18386
G1 X108.935 Y123.668 E.01667
G1 X113.668 Y118.935 E.20743
G1 X114.206 Y118.935 E.01667
G1 X108.935 Y124.206 E.23101
G1 X108.935 Y124.744 E.01667
G1 X114.744 Y118.935 E.25458
G1 X115.282 Y118.935 E.01667
G1 X108.935 Y125.282 E.27815
G1 X108.935 Y125.82 E.01667
G1 X115.82 Y118.935 E.30172
G1 X116.357 Y118.935 E.01667
G1 X108.935 Y126.357 E.3253
G1 X108.935 Y126.895 E.01667
G1 X116.895 Y118.935 E.34887
G1 X117.433 Y118.935 E.01667
G1 X108.935 Y127.433 E.37244
G1 X108.935 Y127.971 E.01667
G1 X117.971 Y118.935 E.39602
G1 X118.509 Y118.935 E.01667
G1 X108.935 Y128.509 E.41959
G1 X108.935 Y129.047 E.01667
G1 X119.047 Y118.935 E.44316
G1 X119.585 Y118.935 E.01667
G1 X108.935 Y129.585 E.46674
G1 X108.935 Y130.122 E.01667
G1 X120.122 Y118.935 E.49031
G1 X120.66 Y118.935 E.01667
G1 X108.935 Y130.66 E.51388
G1 X108.935 Y131.198 E.01667
G1 X121.198 Y118.935 E.53746
G1 X121.736 Y118.935 E.01667
G1 X108.935 Y131.736 E.56103
G1 X108.935 Y132.274 E.01667
G1 X122.274 Y118.935 E.5846
G1 X122.812 Y118.935 E.01667
G1 X108.935 Y132.812 E.60818
G1 X108.935 Y133.35 E.01667
G1 X123.35 Y118.935 E.63175
G1 X123.887 Y118.935 E.01667
G1 X108.935 Y133.887 E.65532
G1 X108.935 Y134.425 E.01667
G1 X124.425 Y118.935 E.6789
G1 X124.963 Y118.935 E.01667
G1 X108.935 Y134.963 E.70247
G1 X108.935 Y135.501 E.01667
G1 X125.501 Y118.935 E.72604
G1 X126.039 Y118.935 E.01667
G1 X108.935 Y136.039 E.74962
G1 X108.935 Y136.577 E.01667
G1 X126.577 Y118.935 E.77319
G1 X127.115 Y118.935 E.01667
G1 X108.985 Y137.065 E.79458
G1 X109.523 Y137.065 E.01667
G1 X127.652 Y118.935 E.79458
G1 X128.19 Y118.935 E.01667
G1 X110.061 Y137.065 E.79458
G1 X110.599 Y137.065 E.01667
G1 X128.728 Y118.935 E.79458
G1 X129.266 Y118.935 E.01667
G1 X111.137 Y137.065 E.79458
G1 X111.674 Y137.065 E.01667
G1 X129.804 Y118.935 E.79458
G1 X130.342 Y118.935 E.01667
G1 X112.212 Y137.065 E.79458
G1 X112.75 Y137.065 E.01667
G1 X130.879 Y118.935 E.79458
M73 P94 R1
G1 X131.417 Y118.935 E.01667
G1 X113.288 Y137.065 E.79458
G1 X113.826 Y137.065 E.01667
G1 X131.955 Y118.935 E.79458
G1 X132.493 Y118.935 E.01667
G1 X114.364 Y137.065 E.79458
G1 X114.902 Y137.065 E.01667
G1 X133.031 Y118.935 E.79458
G1 X133.569 Y118.935 E.01667
G1 X115.439 Y137.065 E.79458
G1 X115.977 Y137.065 E.01667
G1 X134.107 Y118.935 E.79458
G1 X134.644 Y118.935 E.01667
G1 X116.515 Y137.065 E.79458
G1 X117.053 Y137.065 E.01667
G1 X135.182 Y118.935 E.79458
G1 X135.72 Y118.935 E.01667
G1 X117.591 Y137.065 E.79458
G1 X118.129 Y137.065 E.01667
G1 X136.258 Y118.935 E.79458
G1 X136.796 Y118.935 E.01667
G1 X118.667 Y137.065 E.79458
G1 X119.204 Y137.065 E.01667
G1 X137.334 Y118.935 E.79458
G1 X137.872 Y118.935 E.01667
G1 X119.742 Y137.065 E.79458
G1 X120.28 Y137.065 E.01667
G1 X138.409 Y118.935 E.79458
G1 X138.947 Y118.935 E.01667
G1 X120.818 Y137.065 E.79458
G1 X121.356 Y137.065 E.01667
G1 X139.485 Y118.935 E.79458
G1 X140.023 Y118.935 E.01667
G1 X121.894 Y137.065 E.79458
G1 X122.431 Y137.065 E.01667
G1 X140.561 Y118.935 E.79458
G1 X141.099 Y118.935 E.01667
G1 X122.969 Y137.065 E.79458
G1 X123.507 Y137.065 E.01667
G1 X141.637 Y118.935 E.79458
G1 X142.174 Y118.935 E.01667
G1 X124.045 Y137.065 E.79458
G1 X124.583 Y137.065 E.01667
G1 X142.712 Y118.935 E.79458
G1 X143.25 Y118.935 E.01667
G1 X125.121 Y137.065 E.79458
G1 X125.659 Y137.065 E.01667
G1 X143.788 Y118.935 E.79458
G1 X144.326 Y118.935 E.01667
G1 X126.196 Y137.065 E.79458
G1 X126.734 Y137.065 E.01667
G1 X144.864 Y118.935 E.79458
G1 X145.402 Y118.935 E.01667
G1 X127.272 Y137.065 E.79458
G1 X127.81 Y137.065 E.01667
G1 X145.939 Y118.935 E.79458
G1 X146.477 Y118.935 E.01667
G1 X128.348 Y137.065 E.79458
G1 X128.886 Y137.065 E.01667
G1 X147.015 Y118.935 E.79458
G1 X147.065 Y118.935 E.00154
G1 X147.065 Y119.424 E.01513
G1 X129.424 Y137.065 E.77318
G1 X129.961 Y137.065 E.01667
G1 X147.065 Y119.961 E.74961
G1 X147.065 Y120.499 E.01667
G1 X130.499 Y137.065 E.72603
G1 X131.037 Y137.065 E.01667
M73 P94 R0
G1 X147.065 Y121.037 E.70246
G1 X147.065 Y121.575 E.01667
G1 X131.575 Y137.065 E.67889
G1 X132.113 Y137.065 E.01667
G1 X147.065 Y122.113 E.65531
G1 X147.065 Y122.651 E.01667
G1 X132.651 Y137.065 E.63174
G1 X133.189 Y137.065 E.01667
G1 X147.065 Y123.189 E.60817
G1 X147.065 Y123.726 E.01667
G1 X133.726 Y137.065 E.58459
G1 X134.264 Y137.065 E.01667
G1 X147.065 Y124.264 E.56102
G1 X147.065 Y124.802 E.01667
G1 X134.802 Y137.065 E.53745
G1 X135.34 Y137.065 E.01667
G1 X147.065 Y125.34 E.51387
G1 X147.065 Y125.878 E.01667
G1 X135.878 Y137.065 E.4903
G1 X136.416 Y137.065 E.01667
G1 X147.065 Y126.416 E.46673
G1 X147.065 Y126.954 E.01667
G1 X136.954 Y137.065 E.44315
G1 X137.491 Y137.065 E.01667
G1 X147.065 Y127.491 E.41958
G1 X147.065 Y128.029 E.01667
G1 X138.029 Y137.065 E.39601
G1 X138.567 Y137.065 E.01667
G1 X147.065 Y128.567 E.37243
G1 X147.065 Y129.105 E.01667
G1 X139.105 Y137.065 E.34886
G1 X139.643 Y137.065 E.01667
G1 X147.065 Y129.643 E.32529
G1 X147.065 Y130.181 E.01667
G1 X140.181 Y137.065 E.30172
G1 X140.719 Y137.065 E.01667
G1 X147.065 Y130.719 E.27814
G1 X147.065 Y131.256 E.01667
G1 X141.256 Y137.065 E.25457
G1 X141.794 Y137.065 E.01667
G1 X147.065 Y131.794 E.231
G1 X147.065 Y132.332 E.01667
G1 X142.332 Y137.065 E.20742
G1 X142.87 Y137.065 E.01667
G1 X147.065 Y132.87 E.18385
G1 X147.065 Y133.408 E.01667
G1 X143.408 Y137.065 E.16028
G1 X143.946 Y137.065 E.01667
G1 X147.065 Y133.946 E.1367
G1 X147.065 Y134.483 E.01667
G1 X144.483 Y137.065 E.11313
G1 X145.021 Y137.065 E.01667
G1 X147.065 Y135.021 E.08956
G1 X147.065 Y135.559 E.01667
G1 X145.559 Y137.065 E.06598
G1 X146.097 Y137.065 E.01667
G1 X147.065 Y136.097 E.04241
G1 X147.065 Y136.635 E.01667
G1 X146.465 Y137.234 E.02627
; CHANGE_LAYER
; Z_HEIGHT: 23.8
; LAYER_HEIGHT: 0.199999
; WIPE_START
G1 F15000
G1 X147.065 Y136.635 E-.32216
G1 X147.065 Y136.097 E-.20438
G1 X146.63 Y136.531 E-.23346
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 175/176
; update layer progress
M73 L175
M991 S0 P174 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z24 I-.028 J-1.217 P1  F42000
G1 X108.602 Y137.398 Z24
G1 Z23.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F15476.087
M204 S6000
G1 X108.602 Y118.602 E.62349
G1 X147.398 Y118.602 E1.28693
G1 X147.398 Y137.398 E.62349
G1 X108.662 Y137.398 E1.28494
M204 S250
G1 X108.21 Y137.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z24.2 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X109.535 Y137.234
G1 Z23.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42324
G1 F15000
M204 S6000
G1 X108.935 Y136.635 E.02628
G1 X108.935 Y136.097 E.01667
G1 X109.903 Y137.065 E.04242
G1 X110.441 Y137.065 E.01667
G1 X108.935 Y135.559 E.06599
G1 X108.935 Y135.021 E.01667
G1 X110.979 Y137.065 E.08957
G1 X111.517 Y137.065 E.01667
G1 X108.935 Y134.483 E.11314
G1 X108.935 Y133.945 E.01667
G1 X112.055 Y137.065 E.13671
G1 X112.592 Y137.065 E.01667
G1 X108.935 Y133.408 E.16029
G1 X108.935 Y132.87 E.01667
G1 X113.13 Y137.065 E.18386
G1 X113.668 Y137.065 E.01667
G1 X108.935 Y132.332 E.20743
G1 X108.935 Y131.794 E.01667
G1 X114.206 Y137.065 E.231
G1 X114.744 Y137.065 E.01667
G1 X108.935 Y131.256 E.25458
M73 P95 R0
G1 X108.935 Y130.718 E.01667
G1 X115.282 Y137.065 E.27815
G1 X115.82 Y137.065 E.01667
G1 X108.935 Y130.18 E.30172
G1 X108.935 Y129.643 E.01667
G1 X116.357 Y137.065 E.3253
G1 X116.895 Y137.065 E.01667
G1 X108.935 Y129.105 E.34887
G1 X108.935 Y128.567 E.01667
G1 X117.433 Y137.065 E.37244
G1 X117.971 Y137.065 E.01667
G1 X108.935 Y128.029 E.39602
G1 X108.935 Y127.491 E.01667
G1 X118.509 Y137.065 E.41959
G1 X119.047 Y137.065 E.01667
G1 X108.935 Y126.953 E.44316
G1 X108.935 Y126.415 E.01667
G1 X119.585 Y137.065 E.46674
G1 X120.122 Y137.065 E.01667
G1 X108.935 Y125.878 E.49031
G1 X108.935 Y125.34 E.01667
G1 X120.66 Y137.065 E.51388
G1 X121.198 Y137.065 E.01667
G1 X108.935 Y124.802 E.53746
G1 X108.935 Y124.264 E.01667
G1 X121.736 Y137.065 E.56103
G1 X122.274 Y137.065 E.01667
G1 X108.935 Y123.726 E.5846
G1 X108.935 Y123.188 E.01667
G1 X122.812 Y137.065 E.60818
G1 X123.35 Y137.065 E.01667
G1 X108.935 Y122.651 E.63175
G1 X108.935 Y122.113 E.01667
G1 X123.887 Y137.065 E.65532
G1 X124.425 Y137.065 E.01667
G1 X108.935 Y121.575 E.6789
G1 X108.935 Y121.037 E.01667
G1 X124.963 Y137.065 E.70247
G1 X125.501 Y137.065 E.01667
G1 X108.935 Y120.499 E.72604
G1 X108.935 Y119.961 E.01667
G1 X126.039 Y137.065 E.74961
G1 X126.577 Y137.065 E.01667
G1 X108.935 Y119.423 E.77319
G1 X108.935 Y118.935 E.01512
G1 X108.985 Y118.935 E.00154
G1 X127.114 Y137.065 E.79458
G1 X127.652 Y137.065 E.01667
G1 X109.523 Y118.935 E.79458
G1 X110.061 Y118.935 E.01667
G1 X128.19 Y137.065 E.79458
G1 X128.728 Y137.065 E.01667
G1 X110.599 Y118.935 E.79458
G1 X111.137 Y118.935 E.01667
G1 X129.266 Y137.065 E.79458
G1 X129.804 Y137.065 E.01667
G1 X111.674 Y118.935 E.79458
G1 X112.212 Y118.935 E.01667
G1 X130.342 Y137.065 E.79458
G1 X130.879 Y137.065 E.01667
G1 X112.75 Y118.935 E.79458
G1 X113.288 Y118.935 E.01667
G1 X131.417 Y137.065 E.79458
G1 X131.955 Y137.065 E.01667
G1 X113.826 Y118.935 E.79458
G1 X114.364 Y118.935 E.01667
G1 X132.493 Y137.065 E.79458
G1 X133.031 Y137.065 E.01667
G1 X114.902 Y118.935 E.79458
G1 X115.439 Y118.935 E.01667
G1 X133.569 Y137.065 E.79458
G1 X134.107 Y137.065 E.01667
G1 X115.977 Y118.935 E.79458
G1 X116.515 Y118.935 E.01667
G1 X134.644 Y137.065 E.79458
G1 X135.182 Y137.065 E.01667
G1 X117.053 Y118.935 E.79458
G1 X117.591 Y118.935 E.01667
G1 X135.72 Y137.065 E.79458
G1 X136.258 Y137.065 E.01667
G1 X118.129 Y118.935 E.79458
G1 X118.666 Y118.935 E.01667
G1 X136.796 Y137.065 E.79458
G1 X137.334 Y137.065 E.01667
G1 X119.204 Y118.935 E.79458
G1 X119.742 Y118.935 E.01667
G1 X137.872 Y137.065 E.79458
G1 X138.409 Y137.065 E.01667
G1 X120.28 Y118.935 E.79458
G1 X120.818 Y118.935 E.01667
G1 X138.947 Y137.065 E.79458
G1 X139.485 Y137.065 E.01667
G1 X121.356 Y118.935 E.79458
G1 X121.894 Y118.935 E.01667
G1 X140.023 Y137.065 E.79458
G1 X140.561 Y137.065 E.01667
G1 X122.431 Y118.935 E.79458
G1 X122.969 Y118.935 E.01667
G1 X141.099 Y137.065 E.79458
G1 X141.637 Y137.065 E.01667
G1 X123.507 Y118.935 E.79458
G1 X124.045 Y118.935 E.01667
G1 X142.174 Y137.065 E.79458
G1 X142.712 Y137.065 E.01667
G1 X124.583 Y118.935 E.79458
G1 X125.121 Y118.935 E.01667
G1 X143.25 Y137.065 E.79458
G1 X143.788 Y137.065 E.01667
G1 X125.659 Y118.935 E.79458
G1 X126.196 Y118.935 E.01667
G1 X144.326 Y137.065 E.79458
G1 X144.864 Y137.065 E.01667
G1 X126.734 Y118.935 E.79458
G1 X127.272 Y118.935 E.01667
G1 X145.402 Y137.065 E.79458
G1 X145.939 Y137.065 E.01667
G1 X127.81 Y118.935 E.79458
G1 X128.348 Y118.935 E.01667
G1 X146.477 Y137.065 E.79458
G1 X147.015 Y137.065 E.01667
G1 X128.886 Y118.935 E.79458
G1 X129.424 Y118.935 E.01667
G1 X147.065 Y136.576 E.77318
G1 X147.065 Y136.039 E.01667
G1 X129.961 Y118.935 E.74961
G1 X130.499 Y118.935 E.01667
G1 X147.065 Y135.501 E.72603
G1 X147.065 Y134.963 E.01667
G1 X131.037 Y118.935 E.70246
G1 X131.575 Y118.935 E.01667
G1 X147.065 Y134.425 E.67889
G1 X147.065 Y133.887 E.01667
G1 X132.113 Y118.935 E.65531
G1 X132.651 Y118.935 E.01667
G1 X147.065 Y133.349 E.63174
G1 X147.065 Y132.811 E.01667
G1 X133.189 Y118.935 E.60817
G1 X133.726 Y118.935 E.01667
G1 X147.065 Y132.274 E.58459
G1 X147.065 Y131.736 E.01667
G1 X134.264 Y118.935 E.56102
G1 X134.802 Y118.935 E.01667
G1 X147.065 Y131.198 E.53745
G1 X147.065 Y130.66 E.01667
G1 X135.34 Y118.935 E.51387
G1 X135.878 Y118.935 E.01667
G1 X147.065 Y130.122 E.4903
G1 X147.065 Y129.584 E.01667
G1 X136.416 Y118.935 E.46673
G1 X136.954 Y118.935 E.01667
G1 X147.065 Y129.047 E.44315
G1 X147.065 Y128.509 E.01667
G1 X137.491 Y118.935 E.41958
M73 P96 R0
G1 X138.029 Y118.935 E.01667
G1 X147.065 Y127.971 E.39601
G1 X147.065 Y127.433 E.01667
G1 X138.567 Y118.935 E.37244
G1 X139.105 Y118.935 E.01667
G1 X147.065 Y126.895 E.34886
G1 X147.065 Y126.357 E.01667
G1 X139.643 Y118.935 E.32529
G1 X140.181 Y118.935 E.01667
G1 X147.065 Y125.819 E.30172
G1 X147.065 Y125.282 E.01667
G1 X140.718 Y118.935 E.27814
G1 X141.256 Y118.935 E.01667
G1 X147.065 Y124.744 E.25457
G1 X147.065 Y124.206 E.01667
G1 X141.794 Y118.935 E.231
G1 X142.332 Y118.935 E.01667
G1 X147.065 Y123.668 E.20742
G1 X147.065 Y123.13 E.01667
G1 X142.87 Y118.935 E.18385
G1 X143.408 Y118.935 E.01667
G1 X147.065 Y122.592 E.16028
G1 X147.065 Y122.054 E.01667
G1 X143.946 Y118.935 E.1367
G1 X144.483 Y118.935 E.01667
G1 X147.065 Y121.517 E.11313
G1 X147.065 Y120.979 E.01667
G1 X145.021 Y118.935 E.08956
G1 X145.559 Y118.935 E.01667
G1 X147.065 Y120.441 E.06598
G1 X147.065 Y119.903 E.01667
G1 X146.097 Y118.935 E.04241
G1 X146.635 Y118.935 E.01667
G1 X147.234 Y119.535 E.02627
; CHANGE_LAYER
; Z_HEIGHT: 24
; LAYER_HEIGHT: 0.200001
; WIPE_START
G1 F15000
G1 X146.635 Y118.935 E-.32216
G1 X146.097 Y118.935 E-.20438
G1 X146.531 Y119.37 E-.23346
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 176/176
; update layer progress
M73 L176
M991 S0 P175 ;notify layer change
M106 S198.9
; OBJECT_ID: 15
M204 S10000
G17
G3 Z24.2 I-.527 J-1.097 P1  F42000
G1 X108.21 Y137.79 Z24.2
G1 Z24
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F12000
M204 S5000
G1 X108.21 Y118.21 E.60164
G1 X147.79 Y118.21 E1.21618
G1 X147.79 Y137.79 E.60164
G1 X108.27 Y137.79 E1.21434
; WIPE_START
M204 S6000
G1 X108.264 Y135.79 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z24.4 I1.217 J0 P1  F42000
;========Date 20250206========
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
 ; timelapse without wipe tower
M971 S11 C10 O0

M623

G1 X146.947 Y137.583
G1 Z24
G1 E.8 F1800
; FEATURE: Top surface
G1 F12000
M204 S2000
G1 X147.583 Y136.947 E.02764
G1 X147.583 Y136.413
G1 X146.413 Y137.583 E.05081
G1 X145.88 Y137.583
G1 X147.583 Y135.88 E.07399
G1 X147.583 Y135.347
G1 X145.347 Y137.583 E.09716
G1 X144.814 Y137.583
G1 X147.583 Y134.814 E.12033
G1 X147.583 Y134.28
G1 X144.28 Y137.583 E.1435
G1 X143.747 Y137.583
G1 X147.583 Y133.747 E.16668
G1 X147.583 Y133.214
G1 X143.214 Y137.583 E.18985
G1 X142.681 Y137.583
G1 X147.583 Y132.681 E.21302
G1 X147.583 Y132.147
G1 X142.147 Y137.583 E.23619
G1 X141.614 Y137.583
G1 X147.583 Y131.614 E.25937
G1 X147.583 Y131.081
G1 X141.081 Y137.583 E.28254
G1 X140.547 Y137.583
G1 X147.583 Y130.547 E.30571
G1 X147.583 Y130.014
G1 X140.014 Y137.583 E.32888
G1 X139.481 Y137.583
G1 X147.583 Y129.481 E.35206
G1 X147.583 Y128.948
G1 X138.948 Y137.583 E.37523
G1 X138.414 Y137.583
G1 X147.583 Y128.414 E.3984
G1 X147.583 Y127.881
G1 X137.881 Y137.583 E.42157
G1 X137.348 Y137.583
G1 X147.583 Y127.348 E.44475
G1 X147.583 Y126.815
G1 X136.815 Y137.583 E.46792
G1 X136.281 Y137.583
G1 X147.583 Y126.281 E.49109
G1 X147.583 Y125.748
G1 X135.748 Y137.583 E.51426
G1 X135.215 Y137.583
G1 X147.583 Y125.215 E.53744
G1 X147.583 Y124.682
G1 X134.682 Y137.583 E.56061
G1 X134.148 Y137.583
G1 X147.583 Y124.148 E.58378
G1 X147.583 Y123.615
G1 X133.615 Y137.583 E.60696
G1 X133.082 Y137.583
G1 X147.583 Y123.082 E.63013
G1 X147.583 Y122.549
G1 X132.549 Y137.583 E.6533
G1 X132.015 Y137.583
G1 X147.583 Y122.015 E.67647
G1 X147.583 Y121.482
G1 X131.482 Y137.583 E.69965
G1 X130.949 Y137.583
G1 X147.583 Y120.949 E.72282
G1 X147.583 Y120.416
G1 X130.416 Y137.583 E.74599
G1 X129.882 Y137.583
G1 X147.583 Y119.882 E.76916
G1 X147.583 Y119.349
G1 X129.349 Y137.583 E.79234
G1 X128.816 Y137.583
G1 X147.583 Y118.816 E.81551
G1 X147.448 Y118.417
G1 X128.283 Y137.583 E.83282
G1 X127.749 Y137.583
G1 X146.915 Y118.417 E.83282
G1 X146.381 Y118.417
G1 X127.216 Y137.583 E.83282
G1 X126.683 Y137.583
G1 X145.848 Y118.417 E.83282
G1 X145.315 Y118.417
G1 X126.15 Y137.583 E.83282
G1 X125.616 Y137.583
G1 X144.782 Y118.417 E.83282
G1 X144.248 Y118.417
G1 X125.083 Y137.583 E.83282
G1 X124.55 Y137.583
G1 X143.715 Y118.417 E.83282
G1 X143.182 Y118.417
G1 X124.016 Y137.583 E.83282
M73 P97 R0
G1 X123.483 Y137.583
G1 X142.648 Y118.417 E.83282
G1 X142.115 Y118.417
G1 X122.95 Y137.583 E.83282
G1 X122.417 Y137.583
G1 X141.582 Y118.417 E.83282
G1 X141.049 Y118.417
G1 X121.883 Y137.583 E.83282
G1 X121.35 Y137.583
G1 X140.515 Y118.417 E.83282
G1 X139.982 Y118.417
G1 X120.817 Y137.583 E.83282
G1 X120.284 Y137.583
G1 X139.449 Y118.417 E.83282
G1 X138.916 Y118.417
G1 X119.75 Y137.583 E.83282
G1 X119.217 Y137.583
G1 X138.382 Y118.417 E.83282
G1 X137.849 Y118.417
G1 X118.684 Y137.583 E.83282
G1 X118.151 Y137.583
G1 X137.316 Y118.417 E.83282
G1 X136.783 Y118.417
G1 X117.617 Y137.583 E.83282
G1 X117.084 Y137.583
G1 X136.249 Y118.417 E.83282
G1 X135.716 Y118.417
G1 X116.551 Y137.583 E.83282
G1 X116.018 Y137.583
G1 X135.183 Y118.417 E.83282
G1 X134.65 Y118.417
G1 X115.484 Y137.583 E.83282
G1 X114.951 Y137.583
G1 X134.116 Y118.417 E.83282
G1 X133.583 Y118.417
G1 X114.418 Y137.583 E.83282
G1 X113.885 Y137.583
G1 X133.05 Y118.417 E.83282
G1 X132.517 Y118.417
G1 X113.351 Y137.583 E.83282
G1 X112.818 Y137.583
G1 X131.983 Y118.417 E.83282
G1 X131.45 Y118.417
G1 X112.285 Y137.583 E.83282
G1 X111.752 Y137.583
G1 X130.917 Y118.417 E.83282
G1 X130.384 Y118.417
G1 X111.218 Y137.583 E.83282
G1 X110.685 Y137.583
G1 X129.85 Y118.417 E.83282
G1 X129.317 Y118.417
G1 X110.152 Y137.583 E.83282
G1 X109.619 Y137.583
G1 X128.784 Y118.417 E.83282
G1 X128.251 Y118.417
G1 X109.085 Y137.583 E.83282
G1 X108.552 Y137.583
G1 X127.717 Y118.417 E.83282
G1 X127.184 Y118.417
G1 X108.417 Y137.184 E.8155
G1 X108.417 Y136.651
G1 X126.651 Y118.417 E.79233
M73 P98 R0
G1 X126.118 Y118.417
G1 X108.417 Y136.118 E.76916
G1 X108.417 Y135.584
G1 X125.584 Y118.417 E.74598
G1 X125.051 Y118.417
G1 X108.417 Y135.051 E.72281
G1 X108.417 Y134.518
G1 X124.518 Y118.417 E.69964
G1 X123.984 Y118.417
G1 X108.417 Y133.984 E.67647
G1 X108.417 Y133.451
G1 X123.451 Y118.417 E.65329
G1 X122.918 Y118.417
G1 X108.417 Y132.918 E.63012
G1 X108.417 Y132.385
G1 X122.385 Y118.417 E.60695
G1 X121.851 Y118.417
G1 X108.417 Y131.851 E.58378
G1 X108.417 Y131.318
G1 X121.318 Y118.417 E.5606
G1 X120.785 Y118.417
G1 X108.417 Y130.785 E.53743
G1 X108.417 Y130.252
G1 X120.252 Y118.417 E.51426
G1 X119.718 Y118.417
G1 X108.417 Y129.718 E.49109
G1 X108.417 Y129.185
G1 X119.185 Y118.417 E.46791
G1 X118.652 Y118.417
G1 X108.417 Y128.652 E.44474
G1 X108.417 Y128.119
G1 X118.119 Y118.417 E.42157
G1 X117.585 Y118.417
G1 X108.417 Y127.585 E.39839
G1 X108.417 Y127.052
G1 X117.052 Y118.417 E.37522
G1 X116.519 Y118.417
G1 X108.417 Y126.519 E.35205
G1 X108.417 Y125.986
G1 X115.986 Y118.417 E.32888
G1 X115.452 Y118.417
G1 X108.417 Y125.452 E.3057
G1 X108.417 Y124.919
G1 X114.919 Y118.417 E.28253
G1 X114.386 Y118.417
G1 X108.417 Y124.386 E.25936
G1 X108.417 Y123.853
G1 X113.853 Y118.417 E.23619
G1 X113.319 Y118.417
G1 X108.417 Y123.319 E.21301
G1 X108.417 Y122.786
G1 X112.786 Y118.417 E.18984
G1 X112.253 Y118.417
G1 X108.417 Y122.253 E.16667
G1 X108.417 Y121.72
G1 X111.72 Y118.417 E.1435
G1 X111.186 Y118.417
G1 X108.417 Y121.186 E.12032
G1 X108.417 Y120.653
G1 X110.653 Y118.417 E.09715
G1 X110.12 Y118.417
G1 X108.417 Y120.12 E.07398
G1 X108.417 Y119.587
G1 X109.587 Y118.417 E.05081
G1 X109.053 Y118.417
G1 X108.417 Y119.053 E.02763
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F12000
M204 S6000
G1 X109.053 Y118.417 E-.34173
G1 X109.587 Y118.417 E-.20264
G1 X109.185 Y118.819 E-.21563
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z24.4 I1.217 J0 P1  F42000
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20230428 =====================
M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G1 E-0.8 F1800 ; retract
G1 Z24.5 F900 ; lower z a little
G1 X65 Y245 F12000 ; move to safe pos 
G1 Y265 F3000

G1 X65 Y245 F12000
G1 Y265 F3000
M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

G1 X100 F12000 ; wipe
; pull back filament to AMS
M620 S255
G1 X20 Y50 F12000
G1 Y-3
T255
G1 X65 F12000
G1 Y265
G1 X100 F12000 ; wipe
M621 S255
M104 S0 ; turn off hotend

M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
    M400 ; wait all motion done
    M991 S0 P-1 ;end smooth timelapse at safe pos
    M400 S3 ;wait for last picture to be taken
M623; end of "timelapse_record_flag"

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z124 F600
M73 P99 R0
    G1 Z122

M400 P100
M17 R ; restore z current

G90
G1 X128 Y250 F3600

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0

M17 X0.8 Y0.8 Z0.5 ; lower motor current to 45% power
M73 P100 R0
; EXECUTABLE_BLOCK_END

